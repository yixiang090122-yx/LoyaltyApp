﻿using Microsoft.AspNetCore.Mvc;

namespace LoyaltyAppAPI.Controllers
{
    public class GeneralFunction
    {
        public const string Domain = "https://localhost:5104/"; 
        public static DateTime GetCurrentMalaysiaDateTime()
        {
            // Define Malaysia timezone offset (+08:00)
            TimeSpan malaysiaOffset = TimeSpan.FromHours(8);
            // Create a custom TimeZoneInfo object for Malaysia
            TimeZoneInfo malaysiaTimeZone = TimeZoneInfo.CreateCustomTimeZone("Malaysia Standard Time", malaysiaOffset, "Malaysia", "Malaysia Standard Time");

            // Get current UTC time
            DateTime utcNow = DateTime.UtcNow;

            // Convert UTC time to Malaysia time
            DateTime malaysiaDateTime = TimeZoneInfo.ConvertTimeFromUtc(utcNow, malaysiaTimeZone);

            return malaysiaDateTime;
        }

        public static string GeneratePointCode(int charactor)
        {
            Random random = new Random();
            char[] word = new char[charactor];

            for (int i = 0; i < word.Length; i++)
            {
                var number = random.Next(0, 2);
                if (number == 0)
                {
                    word[i] = (char)random.Next(48, 58);
                }
                else
                {
                    word[i] = (char)random.Next(65, 91);
                }
            }
            string PointCode = new string(word);
            return PointCode;
        }

        public static bool IsValidPhoneNumber(string phoneNumber)
        {
            return !string.IsNullOrEmpty(phoneNumber) &&
                   phoneNumber.StartsWith("0") &&
                   (phoneNumber.Length == 10 || phoneNumber.Length == 11) &&
                   phoneNumber.Skip(1).All(char.IsDigit);
        }

        // Members are stored as "+6" + local number (e.g. +60123456789).
        // Accepts 0123456789, 60123456789 or +60123456789 (spaces and dashes are ignored).
        // Returns null when the number is not valid.
        public static string? NormalizePhoneNumber(string? phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(phoneNumber))
            {
                return null;
            }

            var number = phoneNumber.Replace(" ", "").Replace("-", "");
            if (number.StartsWith("+6"))
            {
                number = number.Substring(2);
            }
            else if (number.StartsWith("6"))
            {
                number = number.Substring(1);
            }

            return IsValidPhoneNumber(number) ? "+6" + number : null;
        }
    }
}
