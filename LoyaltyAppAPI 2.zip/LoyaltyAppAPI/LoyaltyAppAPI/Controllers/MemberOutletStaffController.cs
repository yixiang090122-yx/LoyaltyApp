﻿using LoyaltyAppAPI.DTO.Outlet;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Scrypt;
using System.Security.Claims;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Member")]
    [Tags("Members - Outlet Staff")]
    [ApiController]
    [Authorize]
    public class MemberOutletStaffController : ControllerBase
    {
        private readonly AppDbContext db;
        private IConfiguration _configuration;
        ScryptEncoder encoder = new ScryptEncoder();
        IWebHostEnvironment _iwebhost;
        public MemberOutletStaffController(AppDbContext context, IConfiguration configuration, IWebHostEnvironment iwebhost)
        {
            db = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
        }

        [HttpGet("{OutletGUID}")]
        public async Task<ActionResult<IEnumerable<OutletStaff>>> GetAllOutletStaff(string OutletGUID)
        {
            if (db.OutletStaffs == null)
            {
                return NotFound();
            }
            return await db.OutletStaffs.Include(e => e.Outlet)
                .Where(e => e.Outlet.OutletGUID == OutletGUID).ToListAsync();
        }
    }
}
