﻿using LoyaltyAppAPI.DTO.Point;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Admin")]
    [Tags("Admin - Manage Point")]
    [ApiController]
    [Authorize]
    public class ManagePointController : ControllerBase
    {
        public IConfiguration _configuration;
        public AppDbContext _context;
        IWebHostEnvironment _iwebhost;

        public ManagePointController(IConfiguration configuration, AppDbContext context, IWebHostEnvironment iwebhost)
        {
            _context = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
        }

        [HttpGet]
        public IActionResult GetAllPoint()
        {
            return Ok(_context.PointRecords.ToList());
        }

        [HttpGet]
        public IActionResult GetAllPointAssignRecord()
        {
            return Ok(_context.PointRecords.Include(e => e.Member).Include(e => e.OutletStaff).Include(e => e.OutletStaff.Outlet).ToList());
        }


        [HttpPost]
        public async Task<IActionResult> OutletAssignPoint(OutletAssignRecord assignRecordParam)
        {
            var phoneNumber = GeneralFunction.NormalizePhoneNumber(assignRecordParam.PhoneNumber);
            if (phoneNumber == null)
            {
                return BadRequest("The input must be a valid phone number starting with 0.[Example 0123456789 or 01123456789]");
            }
            assignRecordParam.PhoneNumber = phoneNumber;
            var member = await _context.Members
              .FirstOrDefaultAsync(x => x.PhoneNumber == assignRecordParam.PhoneNumber);
            if (member == null)
            {
                return BadRequest("Member Not Found");

            }
            var getBranchStaff = await _context.OutletStaffs
                     .FirstOrDefaultAsync(e => e.Pin == assignRecordParam.Pin && e.Outlet.OutletID == assignRecordParam.OutletID);
            if (getBranchStaff == null)
            {
                return BadRequest("Staff Pin Incorrect");
            }


            PointRecord pointRecord = new PointRecord();
            pointRecord.PointRecordGUID = "PointRecord-" + Guid.NewGuid();
            pointRecord.Code = null;
            pointRecord.Point = assignRecordParam.Point;
            pointRecord.MemberID = member.MemberID;
            pointRecord.DateAssign = DateTime.Now;
            pointRecord.Description = $"Assign {assignRecordParam.Point} point to Member with phone number {assignRecordParam.PhoneNumber} by staff {getBranchStaff.OutletStaffName}.";
            pointRecord.PointRecordStatus = PointRecordStatus.Approve;
            pointRecord.OutletStaffID = getBranchStaff.OutletStaffID;

            _context.Add(pointRecord);
            var getwallet = _context.Members.FirstOrDefault(e => e.MemberID == member.MemberID);
            getwallet.Point += assignRecordParam.Point;
            try
            {

                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return BadRequest("Outlet Assign Point Fail:" + ex.Message);

            }
            return Ok("Outlet Assign Point Successful.");



        }

        [HttpGet("{OutletID}")]
        public async Task<IEnumerable<PointRecord>> GetAllPointAssignRecordByOutletId(int OutletID)
        {
            var getPointRecord = await _context.PointRecords.Include(e => e.OutletStaff).Include(e => e.Member).Where(x => x.OutletStaff.OutletID == OutletID).ToListAsync();
            return getPointRecord;
        }


        [HttpGet("{id}")]
        public IActionResult GetAllPointAssignRecordByPointId(int id)
        {
            return Ok(_context.PointRecords.Include(e => e.Member).Include(e => e.OutletStaff).Include(e => e.OutletStaff.Outlet).FirstOrDefault(x => x.PointRecordID == id));
        }

        [HttpPost]
        public async Task<IActionResult> RejectPoint([FromBody] RejectPointDTO request)
        {
            if (request.AssignPoint == null)
            {
                return BadRequest("AssignPoint is required.");
            }
            var phoneNumber = GeneralFunction.NormalizePhoneNumber(request.AssignPoint.PhoneNumber);
            if (phoneNumber == null)
            {
                return BadRequest("The input must be a valid phone number starting with 0.[Example 0123456789 or 01123456789]");
            }
            var member = await _context.Members
              .FirstOrDefaultAsync(x => x.PhoneNumber == phoneNumber);
            if (member == null)
            {
                return BadRequest("Member Not Found");

            }
            var getBranchStaff = await _context.OutletStaffs
                     .FirstOrDefaultAsync(e => e.Pin == request.AssignPoint.Pin && e.Outlet.OutletID == request.AssignPoint.OutletID);
            if (getBranchStaff == null)
            {
                return BadRequest("Staff Pin Incorrect");
            }

            var target = await _context.PointRecords.FirstOrDefaultAsync(e => e.PointRecordGUID == request.Id && e.MemberID == member.MemberID);

            if (target == null)
                return NotFound();
            if (target.PointRecordStatus == PointRecordStatus.Rejected)
                return BadRequest("Point Record Already Rejected");

            // An approved record's points were already added to the member, so take them back.
            if (target.PointRecordStatus == PointRecordStatus.Approve)
            {
                member.Point -= target.Point;
            }
            target.PointRecordStatus = PointRecordStatus.Rejected;

            // Optional: grant an adjusted amount instead of the rejected one.
            if (request.AssignPoint.Point > 0)
            {
                PointRecord pointRecord = new PointRecord();
                pointRecord.PointRecordGUID = "PointRecord-" + Guid.NewGuid();
                pointRecord.Code = null;
                pointRecord.Point = request.AssignPoint.Point;
                pointRecord.MemberID = member.MemberID;
                pointRecord.DateAssign = DateTime.Now;
                pointRecord.Description = $"Adjusted point for {phoneNumber}: {request.AssignPoint.Point} instead of {target.Point}.";
                pointRecord.PointRecordStatus = PointRecordStatus.Approve;
                pointRecord.OutletStaffID = getBranchStaff.OutletStaffID;

                _context.Add(pointRecord);
                member.Point += request.AssignPoint.Point;
            }

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return BadRequest("Reject Point Fail:" + ex.Message);
            }
            return Ok();
        }

    }
}
