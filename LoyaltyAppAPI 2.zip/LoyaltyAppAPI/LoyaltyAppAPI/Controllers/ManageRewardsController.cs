﻿using LoyaltyAppAPI.DTO.Reward;
using LoyaltyAppAPI.DTO.Voucher;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Data;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Tags("Admin - Manage Voucher")]
    [Authorize(Roles = "Admin")]
    [ApiController]
    [Authorize]
    public class ManageRewardsController : ControllerBase
    {
        public IConfiguration _configuration;
        public AppDbContext db;
        IWebHostEnvironment _iwebhost;

        public ManageRewardsController(IConfiguration configuration, AppDbContext context, IWebHostEnvironment iwebhost)
        {
            db = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
        }

        [HttpGet]
        public async Task<IEnumerable<Rewards>> GetAllRewards()
        {
            return await db.Rewards.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Rewards>> GetReward(int id)
        {
            var rewards = await db.Rewards.FirstOrDefaultAsync(e => e.RewardsID == id);
            if (rewards == null)
            {
                return NotFound($"Not Found With Id: {id}");
            }
            return rewards;
        }

        [HttpPost]
        public async Task<ActionResult> CreateReward([FromForm] CreateReward rewards, [FromForm] IFormFile? file)
        {
            try
            {
                if (rewards.CreateDate > rewards.ExpireDate)
                {
                    return BadRequest("ExpireDate Cannot Earlier Than CreateDate");
                }
                if (file != null && file.Length > 0)
                {
                    string filename = Guid.NewGuid() + Path.GetExtension(file.FileName);
                    string uploadFilePath = Path.Combine(_iwebhost.WebRootPath, "MerchantReward", filename);

                    using (var stream = new FileStream(uploadFilePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    // Optionally, you can store the file path in the TemplateContent object
                    rewards.Image = filename;
                }


                Rewards newreward = new Rewards()
                {

                    Name = rewards.FullName,
                    Image = rewards.Image,

                    Title = rewards.Title,
                    SubTitle = rewards.SubTitle,


                    ShortTitle = rewards.ShortTitle,
                    Description = rewards.Description,
                    RewardCreatedDate = DateTime.Now,
                    TnC = rewards.TnC,
                    CreateDate = rewards.CreateDate,
                    ExpireDate = rewards.ExpireDate,
                    Status = rewards.Status
                };
                string RandomId = "Reward-" + Guid.NewGuid();
                newreward.Point = rewards.Point;


                newreward.RewardGUID = RandomId;
                db.Rewards.Add(newreward);
                await db.SaveChangesAsync();
                return Ok(rewards);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<ActionResult<Rewards>> EditReward([FromForm] EditReward rewards)
        {
            try
            {
                var findreward = db.Rewards.Where(x => x.RewardsID == rewards.Id).FirstOrDefault();
                if (findreward == null)
                {
                    return NotFound("Reward Not Found");
                }

                if (rewards.CreateDate > rewards.ExpireDate)
                {
                    return BadRequest("ExpireDate Cannot Earlier Than CreateDate");
                }
                if (rewards.file != null && rewards.file.Length > 0)
                {
                    string filename = Guid.NewGuid() + Path.GetExtension(rewards.file.FileName);
                    string uploadFilePath = Path.Combine(_iwebhost.WebRootPath, "MerchantReward", filename);

                    using (var stream = new FileStream(uploadFilePath, FileMode.Create))
                    {
                        await rewards.file.CopyToAsync(stream);
                    }

                    // Optionally, you can store the file path in the TemplateContent object
                    findreward.Image = filename;
                }


                findreward.RewardGUID = findreward.RewardGUID;
                findreward.Name = rewards.Name;

                findreward.Title = rewards.Title;
                findreward.SubTitle = rewards.SubTitle;

                findreward.Point = rewards.Point;
                findreward.ShortTitle = rewards.ShortTitle;
                findreward.Description = rewards.Description;

                findreward.Status = rewards.Status;
                findreward.TnC = rewards.TnC;
                bool checktime = findreward.ExpireDate > DateTime.Now;

                if (checktime == true)
                {
                    findreward.ExpireDate = rewards.ExpireDate;
                    findreward.Status = "Active";
                }
                else
                {
                    findreward.ExpireDate = rewards.ExpireDate;
                    findreward.Status = "Expired";
                }

                findreward.CreateDate = rewards.CreateDate;
                await db.SaveChangesAsync();
                return Ok("Update Successful.");

            }
            catch (Exception ex)
            {
                return BadRequest("Edit Fail:" + ex.Message);
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> DeleteReward(int id)
        {
            try
            {
                var rewards = await db.Rewards.FindAsync(id);

                if (rewards == null)
                {
                    return NotFound("Reward Not Found");
                }
                db.Remove(rewards);
                await db.SaveChangesAsync();
                return Ok("Deleted Successful");

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        public async Task<IEnumerable<Voucher>> GetAllVouchers()
        {
            return await db.Vouchers.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Voucher>> GetVoucher(int id)
        {
            var voucher = await db.Vouchers.Include(x => x.VoucherRules).FirstOrDefaultAsync(e => e.VoucherID == id);
            if (voucher == null)
            {
                return NotFound($"Not Found With Id: {id}");
            }
            return voucher;
        }
        [HttpPost]
        public async Task<ActionResult> CreateVoucher([FromForm] CreateVoucher voucher, [FromForm] IFormFile? file)
        {
            try
            {
                if (voucher.CreatedDate > voucher.ExpiredDate)
                {
                    return BadRequest("ExpireDate Cannot Earlier Than CreateDate");
                }
                if (file != null && file.Length > 0)
                {
                    string filename = Guid.NewGuid() + Path.GetExtension(file.FileName);
                    string uploadFilePath = Path.Combine(_iwebhost.WebRootPath, "MerchantReward", filename);

                    using (var stream = new FileStream(uploadFilePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    // Optionally, you can store the file path in the TemplateContent object
                    voucher.Image = filename;
                }

                var rules = JsonConvert.DeserializeObject<List<VoucherRule>>(voucher.VoucherRules);

                Voucher newreward = new Voucher()
                {

                    VoucherName = voucher.VoucherName,
                    Image = voucher.Image,

                    Title = voucher.Title,
                    Subtitle = voucher.Subtitle,


                    ShortTitle = voucher.ShortTitle,
                    Description = voucher.Description,

                    TNC = voucher.TNC,
                    CreatedDate = voucher.CreatedDate,
                    ExpiredDate = voucher.ExpiredDate,
                    VoucherStatus = "Active",
                    VoucherCreatedDate = DateTime.Now,
                    VoucherRules = rules,
                };
                string RandomId = "Voucher-" + Guid.NewGuid();


                newreward.VoucherGUID = RandomId;
                db.Vouchers.Add(newreward);
                if (rules != null || rules.Count > 0) db.VoucherRules.AddRange(rules);
                await db.SaveChangesAsync();
                return Ok(newreward);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpPost]
        public async Task<ActionResult<Voucher>> EditVoucher([FromForm] EditVoucher rewards)
        {
            try
            {
                var findreward = db.Vouchers.Include(x => x.VoucherRules).Where(x => x.VoucherID == rewards.VoucherID).FirstOrDefault();
                if (findreward == null)
                {
                    return NotFound("Voucher Not Found");
                }

                if (rewards.CreatedDate > rewards.ExpiredDate)
                {
                    return BadRequest("ExpireDate Cannot Earlier Than CreateDate");
                }
                if (rewards.file != null && rewards.file.Length > 0)
                {
                    string filename = Guid.NewGuid() + Path.GetExtension(rewards.file.FileName);
                    string uploadFilePath = Path.Combine(_iwebhost.WebRootPath, "MerchantReward", filename);

                    using (var stream = new FileStream(uploadFilePath, FileMode.Create))
                    {
                        await rewards.file.CopyToAsync(stream);
                    }

                    // Optionally, you can store the file path in the TemplateContent object
                    findreward.Image = filename;
                }

                var rules = JsonConvert.DeserializeObject<List<VoucherRule>>(rewards.VoucherRules);

                var incomingRules = rules;

                foreach (var item in incomingRules)
                {
                    var existingRule = findreward.VoucherRules.FirstOrDefault(x => x.VoucherRuleID == item.VoucherRuleID);

                    if (existingRule != null)
                    {
                        existingRule.StartTime = item.StartTime;
                        existingRule.EndTime = item.EndTime;
                    }
                    else
                    {
                        findreward.VoucherRules.Add(new VoucherRule
                        {
                            VoucherID = item.VoucherID,
                            DayOfWeek = item.DayOfWeek,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                        });
                    }
                }

                var incomingRuleIds = incomingRules
     .Where(r => r.VoucherRuleID > 0)
     .Select(r => r.VoucherRuleID)
     .ToList();
                var rulesToDelete = findreward.VoucherRules.Where(r => r.VoucherRuleID > 0 && !incomingRuleIds.Contains(r.VoucherRuleID)).ToList();

                if (rulesToDelete.Count > 0)
                {
                    db.VoucherRules.RemoveRange(rulesToDelete);
                }


                findreward.VoucherName = rewards.VoucherName;

                findreward.Title = rewards.Title;
                findreward.Subtitle = rewards.Subtitle;

                findreward.ShortTitle = rewards.ShortTitle;
                findreward.Description = rewards.Description;

                findreward.VoucherStatus = rewards.VoucherStatus;
                findreward.TNC = rewards.TNC;
                bool checktime = findreward.ExpiredDate > DateTime.Now;

                if (checktime == true)
                {
                    findreward.ExpiredDate = rewards.ExpiredDate;
                    findreward.VoucherStatus = "Active";
                }
                else
                {
                    findreward.ExpiredDate = rewards.ExpiredDate;
                    findreward.VoucherStatus = "Expired";
                }

                findreward.CreatedDate = rewards.CreatedDate;
                await db.SaveChangesAsync();
                return Ok("Update Successful.");

            }
            catch (Exception ex)
            {
                return BadRequest("Edit Fail:" + ex.Message);
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> DeleteVoucher(int id)
        {
            try
            {
                var rewards = await db.Vouchers.FindAsync(id);

                if (rewards == null)
                {
                    return NotFound("Voucher Not Found");
                }
                db.Remove(rewards);
                await db.SaveChangesAsync();
                return Ok("Deleted Successful");

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
