﻿using LoyaltyAppAPI.DTO.Point;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Scrypt;
using System.Security.Claims;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Member")]
    [Tags("Members - Point")]
    [ApiController]
    [Authorize]
    public class MemberPointController : ControllerBase
    {
        private readonly AppDbContext db;
        private IConfiguration _configuration;
        ScryptEncoder encoder = new ScryptEncoder();
        IWebHostEnvironment _iwebhost;
        public MemberPointController(AppDbContext context, IConfiguration configuration, IWebHostEnvironment iwebhost)
        {
            db = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
        }

        [HttpPost]
        public async Task<IActionResult> AssignPoint(AssignPoint assignRecordParam)
        {
            //var memberwallet = _context.wallets.Where(x => x.PhoneNumber == assignRecordParam.PhoneNumber).FirstOrDefault();
            var member = db.Members
                .FirstOrDefault(x => x.MemberGUID == User.FindFirstValue("MemberGUID"));
            //before create Point record first no need enter Pin first
            //var checkstaft = _context.BranchStaff.FirstOrDefault(x => x.Pin == assignRecordParam.Pin && x.BranchesID == assignRecordParam.BranchesID);

            if (member != null)
            {
                PointRecord pointRecord = new PointRecord();
                pointRecord.PointRecordGUID = "PointRecord-" + Guid.NewGuid();

                pointRecord.Point = assignRecordParam.Point;
                pointRecord.MemberID = member.MemberID;
                pointRecord.DateAssign = DateTime.Now;
                pointRecord.Description = "Assign " + assignRecordParam.Point + " point to Member with phone number " + member.PhoneNumber;
                pointRecord.PointRecordStatus = PointRecordStatus.Pending;

                var pointcode = "";
                while (true)
                {
                    pointcode = GeneralFunction.GeneratePointCode(6);
                    var getpointcode = await db.PointRecords.FirstOrDefaultAsync(e => e.Code == pointcode && e.DateAssign.Date == DateTime.Now.Date);
                    if (getpointcode == null)
                    {
                        break;
                    }
                }
                pointRecord.Code = pointcode;
                db.Add(pointRecord);

                assignRecordParam.Code = pointcode;
                db.SaveChanges();
                return Ok(assignRecordParam);

            }
            else
            {
                return BadRequest($"Member Not Found");
            }
        }

        

        [HttpPost]
        public async Task<IActionResult> ApprovePoint(ApprovePoint assignRecordParam)
        {

            var getOutletStaff = db.OutletStaffs.Include(e=>e.Outlet)
                .FirstOrDefault(e => e.Outlet.OutletGUID == assignRecordParam.OutletGUID&&
                e.Pin == assignRecordParam.Pin);
            if (getOutletStaff == null)
            {
                return BadRequest("Wrong Pin");
            }

            var getmember = db.Members.FirstOrDefault(e => e.MemberGUID == User.FindFirstValue("MemberGUID"));
            if (getmember == null)
            {
                return BadRequest("Member Not Found");
            }

            // Only the member's own code that is still waiting for approval can be approved.
            var findCode = db.PointRecords.FirstOrDefault(e => e.Code == assignRecordParam.Code
                && e.MemberID == getmember.MemberID
                && e.PointRecordStatus == PointRecordStatus.Pending);
            if (findCode == null)
            {
                return BadRequest("Assign Code Not Found");
            }
            if (assignRecordParam.Image != null && assignRecordParam.Image.Length > 0)
            {
                try
                {
                    string filename = Guid.NewGuid() + Path.GetExtension(assignRecordParam.Image.FileName);
                    string uploadFilePath = Path.Combine(_iwebhost.WebRootPath, "Attachment", filename);

                    using (var stream = new FileStream(uploadFilePath, FileMode.Create))
                    {
                        await assignRecordParam.Image.CopyToAsync(stream);
                    }
                    findCode.Image = filename;
                }
                catch (Exception ex)
                {
                    return BadRequest("Upload Image Fail:" + ex.Message);
                }
            }

            findCode.Remark = assignRecordParam.Remark;
            findCode.OutletStaffID = getOutletStaff.OutletStaffID;
           
            if (assignRecordParam.PointRecordStatus == PointRecordStatus.Approve)
            {
                getmember.Point += findCode.Point;
                findCode.PointRecordStatus = PointRecordStatus.Approve;
            }
            else if (assignRecordParam.PointRecordStatus == PointRecordStatus.Rejected)
            {
                findCode.PointRecordStatus = PointRecordStatus.Rejected;
            }
            try
            {
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                return BadRequest("Update Member Point Fail:" + ex.Message);
            }

            return Ok("Assign Point Successful.");
        }
    }
}
