﻿using LoyaltyAppAPI.DTO.Record;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Admin")]
    [Tags("Admin - Manage Records")]
    [ApiController]
    [Authorize]
    public class ManageRecordsController : ControllerBase
    {
        public IConfiguration _configuration;
        public AppDbContext _context;
        IWebHostEnvironment _iwebhost;

        public ManageRecordsController(IConfiguration configuration, AppDbContext context, IWebHostEnvironment iwebhost)
        {
            _context = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
        }

        [HttpGet]
        public IActionResult GetAllRewardAssignRecord()
        {
            var records = _context.RewardRecords
                .Include(e => e.Rewards)
                .Include(e => e.Member)
                .Include(e => e.OutletStaff)
                .Include(e => e.OutletStaff.Outlet)
                .Select(record => new RewardAssignDTO
                {
                    RewardRecordID = record.RewardRecordID,
                    MemberRedeemDateTime = record.MemberRedeemDateTime,
                    OutletName = record.OutletStaff.Outlet.OutletName,
                    OutletStaffName = record.OutletStaff.OutletStaffName,
                    MemberName = record.Member.Name,
                    MemberPhoneNumber = record.Member.PhoneNumber,
                    RewardTitle = record.Rewards.Title,
                    RewardName = record.Rewards.Name,
                    RewardDescription = record.Rewards.Description
                })
                .ToList();


            return Ok(records);
        }

        [HttpGet("{id}")]
        public IActionResult GetRewardAssignRecordById(int id)
        {
            var record = _context.RewardRecords
                .Include(e => e.Rewards)
                .Include(e => e.Member)
                .Include(e => e.OutletStaff)
                .Include(e => e.OutletStaff.Outlet)
                .Where(x => x.RewardRecordID == id)
                .Select(record => new RewardAssignDTO
                {
                    RewardRecordID = record.RewardRecordID,
                    MemberRedeemDateTime = record.MemberRedeemDateTime,
                    OutletName = record.OutletStaff.Outlet.OutletName,
                    OutletStaffName = record.OutletStaff.OutletStaffName,
                    MemberName = record.Member.Name,
                    MemberPhoneNumber = record.Member.PhoneNumber,
                    RewardTitle = record.Rewards.Title,
                    RewardName = record.Rewards.Name,
                    RewardDescription = record.Rewards.Description
                })
                .FirstOrDefault();

            if (record == null)
                return NotFound("Reward record not found.");

            return Ok(record);
        }


        [HttpGet]
        public IActionResult GetAllVoucherAssignRecord()
        {
            var records = _context.VoucherRecords
                .Include(e => e.Voucher)
                .Include(e => e.Member)
                .Include(e => e.OutletStaff)
                .Include(e => e.OutletStaff.Outlet)
                .Select(record => new VoucherAssignDTO
                {
                    VoucherRecordID = record.VoucherRecordID,
                    VoucherName = record.Voucher.VoucherName,
                    Title = record.Voucher.Title,
                    Description = record.Voucher.Description,
                    MemberName = record.Member.Name,
                    MemberPhoneNumber = record.Member.PhoneNumber,
                    OutletName = record.OutletStaff.Outlet.OutletName,
                    OutletStaffName = record.OutletStaff.OutletStaffName,
                    MemberRedeemDateTime = record.MemberRedeemDateTime
                })
                .ToList();

            return Ok(records);
        }

        [HttpGet("{id}")]
        public IActionResult GetVoucherAssignRecordById(int id)
        {
            var record = _context.VoucherRecords
                .Include(e => e.Voucher)
                .Include(e => e.Member)
                .Include(e => e.OutletStaff)
                .Include(e => e.OutletStaff.Outlet)
                .Where(x => x.VoucherRecordID == id)
                .Select(record => new VoucherAssignDTO
                {
                    VoucherRecordID = record.VoucherRecordID,
                    VoucherName = record.Voucher.VoucherName,
                    Title = record.Voucher.Title,
                    Description = record.Voucher.Description,
                    MemberName = record.Member.Name,
                    MemberPhoneNumber = record.Member.PhoneNumber,
                    OutletName = record.OutletStaff.Outlet.OutletName,
                    OutletStaffName = record.OutletStaff.OutletStaffName,
                    MemberRedeemDateTime = record.MemberRedeemDateTime
                })
                .FirstOrDefault();

            if (record == null)
                return NotFound("Voucher record not found.");

            return Ok(record);
        }
    }
}
