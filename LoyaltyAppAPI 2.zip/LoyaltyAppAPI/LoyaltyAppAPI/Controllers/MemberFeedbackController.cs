﻿using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Scrypt;
using System.Security.Claims;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Member")]
    [Tags("Members - Feedback")]
    [ApiController]
    [Authorize]
    public class MemberFeedbackController : ControllerBase
    {
        private readonly AppDbContext db;
        private IConfiguration _configuration;
        ScryptEncoder encoder = new ScryptEncoder();
        IWebHostEnvironment _iwebhost;
        public MemberFeedbackController(AppDbContext context, IConfiguration configuration, IWebHostEnvironment iwebhost)
        {
            db = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
        }
        [AllowAnonymous]
        [HttpPost]
        public IActionResult CreateFeedback(Feedback feedbackParam)
        {
            try
            {
                Feedback feedBackForm = new Feedback();
                feedBackForm.Title = feedbackParam.Title;
                feedBackForm.Description = feedbackParam.Description;
                feedBackForm.Rating = feedbackParam.Rating;
                feedBackForm.Category = feedbackParam.Category;
                feedBackForm.MemberGUID =User.FindFirstValue("MemberGUID")?? feedbackParam.MemberGUID;
                if (feedBackForm.MemberGUID != null)
                {
                    feedBackForm.MemberID = db.Members.Where(m => m.MemberGUID == feedBackForm.MemberGUID).Select(m => (int?)m.MemberID).FirstOrDefault();
                }

                feedBackForm.Location = feedbackParam.Location;
                db.Feedbacks.Add(feedBackForm);
                db.SaveChanges();
                return Ok("Submit Successful");
            }
            catch (Exception ex)
            {
                return BadRequest("Submit Failed");
            }
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Outlet>>> GetAllOutlets()
        {
            if (db.Outlets == null)
            {
                return NotFound();
            }
            return await db.Outlets.ToListAsync();
        }
    }
}
