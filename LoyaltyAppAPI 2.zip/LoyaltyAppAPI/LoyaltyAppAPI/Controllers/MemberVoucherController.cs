using LoyaltyAppAPI.DTO.Voucher;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Scrypt;
using System.Security.Claims;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Member")]
    [Tags("Members - Voucher")]
    [ApiController]
    public class MemberVoucherController : ControllerBase
    {
        private readonly AppDbContext db;
        private IConfiguration _configuration;
        ScryptEncoder encoder = new ScryptEncoder();
        IWebHostEnvironment _iwebhost;
        public MemberVoucherController(AppDbContext context, IConfiguration configuration, IWebHostEnvironment iwebhost)
        {
            db = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
        }
        [AllowAnonymous]
        [HttpGet]
        public async Task<IEnumerable<Voucher>> GetAllVouchers()
        {
            return await db.Vouchers.ToListAsync();
        }
        [AllowAnonymous]
        [HttpGet("{VoucherGUID}")]
        public async Task<ActionResult<Voucher>> GetVoucher(string VoucherGUID)
        {
            var voucher = await db.Vouchers.FirstOrDefaultAsync(e => e.VoucherGUID == VoucherGUID);
            if (voucher == null)
            {
                return NotFound($"Not Found With Id: {VoucherGUID}");
            }
            return voucher;
        }

        [HttpGet]
        public async Task<IEnumerable<Voucher>> GetMemberUnclaimedVouchers()
        {
            var claimedVouchersIds = await db.VoucherRecords.Include(
                x => x.Member).Where(
                x => x.Member.MemberGUID == User.FindFirstValue("MemberGUID")).Select(x => x.VoucherID).ToListAsync();

            var unclaim = await db.Vouchers.Where(
                x => !claimedVouchersIds.Contains(x.VoucherID) &&
                x.CreatedDate.HasValue &&
                x.ExpiredDate.HasValue &&
                x.CreatedDate.Value <= DateTime.Now &&
                x.ExpiredDate.Value >= DateTime.Now).ToListAsync();

            return unclaim;
        }

        [HttpGet("{VoucherGUID}")]
        public async Task<IActionResult> GetAllVoucherRecord(string VoucherGUID)
        {
            var voucher = await db.VoucherRecords.Include(e => e.Voucher).Include(e => e.Member)
                .FirstOrDefaultAsync(e => e.Voucher.VoucherGUID == VoucherGUID
                && e.Member.MemberGUID == User.FindFirstValue("MemberGUID"));
            if (voucher == null)
            {
                return Ok("This Member Can Redeem");
            }
            return BadRequest("Claim Already");

        }
        [HttpPost]
        public async Task<IActionResult> RedeemVoucher(RedeemVoucher redeemVoucher)
        {
            var voucher = await db.Vouchers.FirstOrDefaultAsync(e => e.VoucherGUID == redeemVoucher.VoucherGUID);
            if (voucher == null)
            {
                return NotFound($"Not Found With Id: {redeemVoucher.VoucherGUID}");
            }
            var getmember = await db.Members.FirstOrDefaultAsync(e => e.MemberGUID == User.FindFirstValue("MemberGUID"));



            if (getmember == null)
            {
                return BadRequest("Member Not Found");
            }

            try
            {


                if (!encoder.Compare(redeemVoucher.MemberPassword, getmember.Password))
                {
                    return BadRequest("Wrong Member Password");
                }
            }
            catch
            {
                return BadRequest("Compare Error");
            }

            var getOutletStaff = await db.OutletStaffs
                .FirstOrDefaultAsync(e => e.Pin == redeemVoucher.OutletStaffPin);
            if (getOutletStaff == null)
            {
                return BadRequest("Wrong Outlet Staff Pin");
            }
            if (voucher.ExpiredDate.HasValue && voucher.ExpiredDate.Value < DateTime.Now)
            {
                return BadRequest("Voucher Expired");
            }
            if (await db.VoucherRecords.AnyAsync(e => e.VoucherID == voucher.VoucherID && e.MemberID == getmember.MemberID && e.Claim == true))
            {
                return BadRequest("Claim Already");
            }
            long currentTimeMillis = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            VoucherRecord record = new VoucherRecord()
            {
                VoucherRecordGUID = "VoucherRecord-" + Guid.NewGuid().ToString(),
                MemberID = getmember.MemberID,
                VoucherID = voucher.VoucherID,
                OutletStaffID = getOutletStaff.OutletStaffID,
                Claim = true,
                MemberRedeemDateTime = currentTimeMillis
            };
            db.VoucherRecords.Add(record);
            db.SaveChanges();
            return Ok("Voucher Records Created Successful.");
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<List<Voucher>>> ShowVouchers()
        {
            var memberGuid = User.FindFirstValue("MemberGUID");

            // Case: User not logged in (guest)
            if (User.Identity?.IsAuthenticated != true || string.IsNullOrEmpty(memberGuid))
            {
                var allVouchers = await db.Vouchers.ToListAsync();

                return Ok(allVouchers);
            }

            // Case: Logged in — get member ID from GUID
            var member = await db.Members.FirstOrDefaultAsync(m => m.MemberGUID == memberGuid);
            if (member == null)
                return Unauthorized("Invalid or expired session.");

            int memberId = member.MemberID;

            // Get claimed voucher IDs by this member
            var claimedVoucherIds = await db.VoucherRecords
                .Where(r => r.MemberID == memberId && r.Claim == true)
                .Select(r => r.VoucherID)
                .ToListAsync();

            var now = DateTime.Now;
            var today = now.DayOfWeek.ToString(); // e.g., "Monday"
            var currentTime = now.TimeOfDay;

            // Filter vouchers based on validity and not claimed
            var validVouchers = await db.Vouchers
                .Include(v => v.VoucherRules)
                .Where(v =>
                    v.CreatedDate <= now &&
                    (v.ExpiredDate == null || v.ExpiredDate >= now) &&
                    !claimedVoucherIds.Contains(v.VoucherID) && // Not already claimed
                    (
                        !v.VoucherRules.Any() || // No rules means always valid
                        v.VoucherRules.Any(r =>
                            r.DayOfWeek == today &&
                            r.StartTime <= currentTime &&
                            r.EndTime >= currentTime)
                    )
                )
                .ToListAsync();

            if (!validVouchers.Any())
                return NotFound("No valid vouchers available at this time.");

            return Ok(validVouchers);
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<FilterVouchers>> GetFilterVouchers()
        {
            var memberGuid = User.FindFirstValue("MemberGUID");

            if (User.Identity?.IsAuthenticated != true || string.IsNullOrEmpty(memberGuid))
            {
                var allVoucherss = await db.Vouchers.ToListAsync();

                var results = new FilterVouchers
                {
                    ActiveVouchers = allVoucherss,
                    ClaimedVouchers = null,
                    ExpiredVouchers = null
                };

                return Ok(results);
            }

            var member = await db.Members.FirstOrDefaultAsync(m => m.MemberGUID == memberGuid);
            if (member == null)
                return Unauthorized("Invalid member session.");

            int memberId = member.MemberID;
            var now = DateTime.Now;
            var today = now.DayOfWeek.ToString();
            var currentTime = now.TimeOfDay;

            // Load all vouchers
            var allVouchers = await db.Vouchers
                .Include(v => v.VoucherRules)
                .Where(v => v.CreatedDate.HasValue &&
                            v.ExpiredDate.HasValue)
                .ToListAsync();

            // Get all claimed voucher IDs for this member
            var claimedVoucherIds = await db.VoucherRecords
                .Where(x => x.MemberID == memberId && x.Claim == true)
                .Select(x => x.VoucherID)
                .ToListAsync();

            // 1. Claimed vouchers (all, even expired)
            var claimedVouchers = allVouchers
                .Where(v => claimedVoucherIds.Contains(v.VoucherID))
                .ToList();

            // 2. Expired vouchers (not claimed)
            var expiredVouchers = allVouchers
                .Where(v => !claimedVoucherIds.Contains(v.VoucherID) && v.ExpiredDate.Value < now)
                .ToList();

            // 3. Unclaimed and valid (follow rules)
            var unclaimedValidVouchers = allVouchers
                .Where(v =>
                    !claimedVoucherIds.Contains(v.VoucherID) &&
                    v.CreatedDate.Value <= now &&
                    v.ExpiredDate.Value >= now &&
                    (
                        !v.VoucherRules.Any() || // No rules = always valid
                        v.VoucherRules.Any(r =>
                            r.DayOfWeek == today &&
                            r.StartTime <= currentTime &&
                            r.EndTime >= currentTime)
                    )
                )
                .ToList();

            var result = new FilterVouchers
            {
                ActiveVouchers = unclaimedValidVouchers,
                ClaimedVouchers = claimedVouchers,
                ExpiredVouchers = expiredVouchers
            };

            return Ok(result);
        }

    }
}
