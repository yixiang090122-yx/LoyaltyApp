using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Tags("Admin - Manage Defaults")]
    [Authorize(Roles = "Admin")]
    [ApiController]
    public class ManageDefaultController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ManageDefaultController(AppDbContext context)
        {
            _context = context;
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult CreateDefaults()
        {
            DateTime today = DateTime.Now;
            DateTime oneYearLater = DateTime.Now.AddYears(1);

            List<Highlight> default_highlights = new List<Highlight>()
            {
                new Highlight()
                {
                    HighlightGUID = $"Highlight-{Guid.NewGuid()}",
                    Image = "new-menu.jpg",
                    Title = "New Seasonal Menu - Flavors of Asia",
                    SubTitle = "Limited time only",
                    Description = "Try our chef's latest creations inspired by bold Asian flavors.",
                    TnC = "Available until May 31. Subject to availability.",
                    CreateDate = today,
                    ExpireDate = oneYearLater,
                    Status = "Active",
                },
                new Highlight()
                {
                    HighlightGUID = $"Highlight-{Guid.NewGuid()}",
                    Image = "happy-hour.png",
                    Title = "Weekend Happy Hour",
                    SubTitle = "Every Fri-Sun, 3PM-6PM",
                    Description = "Enjoy up to 30% off selected drinks and snacks every weekend afternoon!",
                    TnC = "For dine-in only. Promo items may vary by location.",
                    CreateDate = today,
                    ExpireDate = oneYearLater,
                    Status = "Active",
                },
                new Highlight()
                {
                    HighlightGUID = $"Highlight-{Guid.NewGuid()}",
                    Image = "birthday-highlight.png",
                    Title = "Celebrate with Us - Birthday Perks!",
                    SubTitle = "Free cake & special voucher",
                    Description = "Celebrate your birthday with a complimentary slice of cake and a birthday voucher.",
                    TnC = "Valid during birthday month. ID required for verification.",
                    CreateDate = today,
                    ExpireDate = oneYearLater,
                    Status = "Active",
                },
            };

            List<Rewards> default_rewards = new List<Rewards>()
            {
                new Rewards()
                {
                    RewardGUID = $"Reward-{Guid.NewGuid()}",
                    Name = "Free Coffee",
                    Image = "free-coffee.png",
                    Title = "Free Coffee",
                    SubTitle = "Redeem a signature coffee",
                    Point = 100,
                    ShortTitle = "",
                    Description = "A hot cup of comfort - redeem your favorite coffee with your points!",
                    TnC = "Redeemable at all outlets. One redemption per transaction.",
                    CreateDate = today,
                    ExpireDate = oneYearLater,
                    Status = "Active",
                    RewardCreatedDate = today,
                },
                new Rewards()
                {
                    RewardGUID = $"Reward-{Guid.NewGuid()}",
                    Name = "RM10 Off",
                    Image = "10-off.png",
                    Title = "RM10 Off",
                    SubTitle = "Save more with your points",
                    Point = 150,
                    ShortTitle = "",
                    Description = "Use your reward points to knock RM10 off your bill.",
                    TnC = "No minimum spend. Points will be deducted upon redemption.",
                    CreateDate = today,
                    ExpireDate = oneYearLater,
                    Status = "Active",
                    RewardCreatedDate = today,
                },
                new Rewards()
                {
                    RewardGUID = $"Reward-{Guid.NewGuid()}",
                    Name = "Exclusive Tumbler",
                    Image = "exclusive-tumbler.png",
                    Title = "Exclusive Tumbler",
                    SubTitle = "Drink in style",
                    Point = 300,
                    ShortTitle = "",
                    Description = "Take home our sleek, eco-friendly branded tumbler.",
                    TnC = "While stocks last. Available for in-store pick-up only.",
                    CreateDate = today,
                    ExpireDate = oneYearLater,
                    Status = "Active",
                    RewardCreatedDate = today,
                },
            };

            List<Voucher> default_vouchers = new List<Voucher>()
            {
                new Voucher()
                {   
                    VoucherGUID = $"Voucher-{Guid.NewGuid()}",
                    VoucherName = "10% Off First Meal",
                    Image = "10-off.png",
                    Title = "Welcome Feast!",
                    Subtitle = "Enjoy 10% off your first order",
                    ShortTitle = "10% Off",
                    Description = "New to our place? Here's a warm welcome - get 10% off your first meal with us!",
                    TNC = "Valid for first-time customers only. Minimum spend RM20. Non-stackable.",
                    CreatedDate = today,
                    ExpiredDate = oneYearLater,
                    VoucherStatus = "Active",
                    VoucherCreatedDate = today,
                },
                new Voucher()
                {
                    VoucherGUID = $"Voucher-{Guid.NewGuid()}",
                    VoucherName = "Free Drink with Combo",
                    Image = "free-combo.png",
                    Title = "Thirsty? We Got You!",
                    Subtitle = "Get 1 free drink with any combo meal",
                    ShortTitle = "Free Drink",
                    Description = "Enjoy a refreshing drink of your choice absolutely FREE when you order any combo set!",
                    TNC = "Valid for dine-in only. Limited to selected drinks.",
                    CreatedDate = today,
                    ExpiredDate = oneYearLater,
                    VoucherStatus = "Active",
                    VoucherCreatedDate = today,
                },
                new Voucher()
                {
                    VoucherGUID = $"Voucher-{Guid.NewGuid()}",
                    VoucherName = "Birthday Voucher",
                    Image = "birthday-highlight.png",
                    Title = "Celebrate Your Day!",
                    Subtitle = "Birthday treats just for you",
                    ShortTitle = "Birthday Perk",
                    Description = "Enjoy a complimentary dessert on us to celebrate your special day1",
                    TNC = "Valid only during birthday week. Dine-in only. One redemption per customer.",
                    CreatedDate = today,
                    ExpiredDate = oneYearLater,
                    VoucherStatus = "Active",
                    VoucherCreatedDate = today,
                },
            };

            if (!_context.Highlights.Any())
            {
                _context.Highlights.AddRange(default_highlights);
            }

            if (!_context.Rewards.Any())
            {
                _context.Rewards.AddRange(default_rewards);
            }

            if (!_context.Vouchers.Any())
            {
                _context.Vouchers.AddRange(default_vouchers);
            }

            if (!_context.Admins.Any())
            {
                _context.Admins.Add(new Admin
                {
                    Username = "admin",
                    Password = "admin123"
                });
            }

            if (!_context.Outlets.Any())
            {
                var outlet = new Outlet
                {
                    OutletGUID = $"Outlet-{Guid.NewGuid()}",
                    OutletName = "Main Branch (Mid Valley)",
                    CreatedDate = today,
                    OutletStatus = OutletStatus.Active
                };
                _context.Outlets.Add(outlet);
                _context.SaveChanges();

                _context.OutletStaffs.Add(new OutletStaff
                {
                    OutletID = outlet.OutletID,
                    OutletStaffName = "Staff John",
                    Pin = "123456",
                    Role = "Staff"
                });
            }

            if (!_context.Members.Any())
            {
                Scrypt.ScryptEncoder encoder = new Scrypt.ScryptEncoder();
                _context.Members.Add(new Member
                {
                    MemberGUID = $"Member-{Guid.NewGuid()}",
                    Name = "Demo Student",
                    Email = "demo@student.com",
                    PhoneNumber = "+60123456789",
                    Password = encoder.Encode("123456"),
                    AccountStatus = AccountStatus.Active,
                    Point = 200,
                    Tier = "Bronze",
                    RegisterTime = today,
                    FirstLogin = false
                });
            }

            _context.SaveChanges();

            return Ok(new
            {
                Message = "Default test data created successfully.",
                AdminAccount = "Username: admin / Password: admin123",
                StaffPin = "123456 (for voucher/reward redemption)",
                DemoMember = "Phone: 0123456789 / Password: 123456 (200 Points)"
            });
        }
    }
}
