﻿using LoyaltyAppAPI.DTO.Highlight;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Scrypt;
using System.Security.Claims;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Member")]
    [Tags("Members - Hightlight")]
    [ApiController]
    [Authorize]
    public class MemberHightlightController : ControllerBase
    {
        private readonly AppDbContext db;
        private IConfiguration _configuration;
        ScryptEncoder encoder = new ScryptEncoder();
        IWebHostEnvironment _iwebhost;
        public MemberHightlightController(AppDbContext context, IConfiguration configuration, IWebHostEnvironment iwebhost)
        {
            db = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
        }
        [AllowAnonymous]
        [HttpGet]
        public async Task<IEnumerable<Highlight>> GetAllHighlights()
        {
            return await db.Highlights
                .OrderByDescending(x => x.CreateDate).ToListAsync();
        }

        [AllowAnonymous]
        [HttpGet("{HightlightGUID}")]
        public async Task<ActionResult<Highlight>> GetHighlight(string HightlightGUID)
        {
            var highlight = await db.Highlights
                .FirstOrDefaultAsync(x => x.HighlightGUID == HightlightGUID);
            if (highlight == null)
            {
                return NotFound();
            }
            return highlight;
        }
    }
}
