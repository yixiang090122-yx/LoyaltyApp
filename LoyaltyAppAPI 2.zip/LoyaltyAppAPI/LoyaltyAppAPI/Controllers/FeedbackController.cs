﻿using LoyaltyAppAPI.DTO.Feedback;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Tags("Admin - Manage Feedback")]
    [Authorize(Roles = "Admin")]
    [ApiController]
    [Authorize]
    public class FeedbackController : ControllerBase
    {
        public IConfiguration _configuration;
        public AppDbContext _context;
        public FeedbackController(IConfiguration configuration, AppDbContext context)
        {
            _context = context;
            _configuration = configuration;
        }


        [HttpGet]
        public IActionResult GetAllFeedbackList()
        {
            return Ok(_context.Feedbacks.ToList());
        }

        [HttpGet("{id}")]
        public IActionResult GetFeedback(int id)
        {
            return Ok(_context.Feedbacks.FirstOrDefault(e => e.FeedbackID == id));
        }

       

        [HttpPost]
        public IActionResult GetFeedbackListFilterUser(GetFeedback feedbackListParam)
        {
            var filter = _context.Feedbacks
                .Where(x => x.MemberID == feedbackListParam.MemberID).ToList();
            if (filter.Count != 0)
            {
                return Ok(filter);
            }
            else
            {
                return BadRequest("No Records Found");
            }

        }
    }
}
