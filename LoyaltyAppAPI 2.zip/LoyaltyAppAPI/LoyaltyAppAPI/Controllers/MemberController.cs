using LoyaltyAppAPI.Configurations;
using LoyaltyAppAPI.DTO.Member;
using LoyaltyAppAPI.Migrations;
using LoyaltyAppAPI.Models;
using LoyaltyAppAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.IdentityModel.Tokens;
using Scrypt;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Member")]
    [Tags("Members")]
    [ApiController]
    public class MemberController : ControllerBase
    {
        private readonly AppDbContext db;
        private IConfiguration _configuration;
        ScryptEncoder encoder = new ScryptEncoder();
        IWebHostEnvironment _iwebhost;
        private readonly IEmailService _emailService;

        public MemberController(AppDbContext context, IConfiguration configuration, IWebHostEnvironment iwebhost, IEmailService emailService)
        {
            db = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
            _emailService = emailService;
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> GenerateOTP([FromBody] RequestOtpDTO request)
        {
            try
            {
                if (request == null || (string.IsNullOrWhiteSpace(request.PhoneNumber) && string.IsNullOrWhiteSpace(request.Email)))
                {
                    return BadRequest("Please provide PhoneNumber or Email.");
                }

                Member? findUser = null;
                if (!string.IsNullOrWhiteSpace(request.PhoneNumber))
                {
                    var phoneNumber = GeneralFunction.NormalizePhoneNumber(request.PhoneNumber);
                    if (phoneNumber == null)
                    {
                        return BadRequest("The input must be a valid phone number starting with 0.[Example 0123456789 or 01123456789]");
                    }
                    findUser = await db.Members.FirstOrDefaultAsync(x => x.PhoneNumber == phoneNumber);
                }
                else if (!string.IsNullOrWhiteSpace(request.Email))
                {
                    findUser = await db.Members.FirstOrDefaultAsync(x => x.Email == request.Email.Trim());
                }

                if (findUser == null)
                {
                    return NotFound("Member not found.");
                }

                var otp = Random.Shared.Next(100000, 999999).ToString();
                findUser.OTP = otp;
                findUser.OTPCreated = GeneralFunction.GetCurrentMalaysiaDateTime();

                await db.SaveChangesAsync();

                bool emailSent = false;
                string? emailError = null;

                if (!string.IsNullOrWhiteSpace(findUser.Email))
                {
                    try
                    {
                        await _emailService.SendOtpEmailAsync(findUser.Email, otp);
                        emailSent = true;
                    }
                    catch (Exception ex)
                    {
                        emailError = ex.Message;
                    }
                }

                return Ok(new
                {
                    Message = emailSent 
                        ? $"OTP generated and sent to {findUser.Email} successfully." 
                        : "OTP generated successfully.",
                    PhoneNumber = findUser.PhoneNumber,
                    Email = findUser.Email,
                    EmailSent = emailSent,
                    EmailError = emailError,
                    OTP = otp,
                    OtpCreated = findUser.OTPCreated
                });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> MemberResetPassword([FromBody] ResetPasswordDTO dto)
        {
            try
            {
                if (dto == null || string.IsNullOrWhiteSpace(dto.NewPassword) || string.IsNullOrWhiteSpace(dto.OTP))
                {
                    return BadRequest("OTP and New Password are required.");
                }

                Member? findMember = null;
                if (!string.IsNullOrWhiteSpace(dto.PhoneNumber))
                {
                    var phoneNumber = GeneralFunction.NormalizePhoneNumber(dto.PhoneNumber);
                    if (phoneNumber != null)
                    {
                        findMember = await db.Members.FirstOrDefaultAsync(x => x.PhoneNumber == phoneNumber);
                    }
                }
                else if (!string.IsNullOrWhiteSpace(dto.Email))
                {
                    findMember = await db.Members.FirstOrDefaultAsync(x => x.Email == dto.Email.Trim());
                }

                if (findMember == null)
                {
                    return BadRequest("Member doesn't exist.");
                }

                if (string.IsNullOrEmpty(findMember.OTP) || findMember.OTP != dto.OTP.Trim())
                {
                    return BadRequest("Invalid OTP.");
                }

                if (findMember.OTPCreated.HasValue)
                {
                    var now = GeneralFunction.GetCurrentMalaysiaDateTime();
                    if ((now - findMember.OTPCreated.Value).TotalMinutes > 10)
                    {
                        return BadRequest("OTP has expired. Please request a new OTP.");
                    }
                }

                findMember.Password = encoder.Encode(dto.NewPassword);
                findMember.OTP = null;
                findMember.OTPCreated = null;

                await db.SaveChangesAsync();
                return Ok(new { Message = "Password reset successfully." });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordDTO dto)
        {
            try
            {
                if (dto == null || string.IsNullOrWhiteSpace(dto.OldPassword) || string.IsNullOrWhiteSpace(dto.NewPassword))
                {
                    return BadRequest("Old password and new password are required.");
                }

                var findMember = await db.Members.FirstOrDefaultAsync(x => x.MemberGUID == User.FindFirstValue("MemberGUID"));
                if (findMember == null)
                {
                    return Unauthorized("Member session invalid.");
                }

                if (!encoder.Compare(dto.OldPassword, findMember.Password))
                {
                    return BadRequest("Incorrect old password.");
                }

                findMember.Password = encoder.Encode(dto.NewPassword);
                await db.SaveChangesAsync();
                return Ok(new { Message = "Password updated successfully." });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> MemberLogin(FindMember memberLogin)
        {
            if (memberLogin == null || string.IsNullOrEmpty(memberLogin.PhoneNumber))
            {
                return BadRequest("Token generation failed:Phone Number is missing.");
            }

            var phoneNumber = GeneralFunction.NormalizePhoneNumber(memberLogin.PhoneNumber);
            if (phoneNumber == null)
            {
                return BadRequest("The input must be a valid phone number starting with 0.[Example 0123456789 or 01123456789]");
            }

            var getMember = await db.Members.FirstOrDefaultAsync(e => e.PhoneNumber == phoneNumber);
            if (getMember == null)
            {
                return Unauthorized("Invalid username or password.");
            }
            if (!string.IsNullOrEmpty(memberLogin.Password))
            {
                if (!encoder.Compare(memberLogin.Password, getMember.Password))
                {
                    return Unauthorized("Invalid username or password.");
                }
            }
            if (getMember.AccountStatus == AccountStatus.Inactive)
            {
                return Unauthorized("Account is inactive.");
            }
            var jwt = _configuration.GetSection("Jwt").Get<Jwt>();
            var claim = new[] {
                    new Claim(JwtRegisteredClaimNames.Sub,_configuration["Jwt:Subject"]),
                    new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
                    new Claim("MemberGUID",getMember.MemberGUID.ToString()),
                     new Claim(ClaimTypes.Role, "Member")
                    };
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key));
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                 jwt.Issuer,
                    jwt.Audience,
                claim,
                expires: DateTime.UtcNow.AddMonths(1),
                signingCredentials: signIn
                );

            getMember.SuccessToken = new JwtSecurityTokenHandler().WriteToken(token);
            getMember.TokenMinutes = "1440"; // 1天的分钟数

            // No e-mail is sent: the OTP is returned in the response so the client can show its own OTP page.
            var otp = Random.Shared.Next(100000, 999999).ToString();
            getMember.OTP = otp;
            getMember.OTPCreated = GeneralFunction.GetCurrentMalaysiaDateTime();
            try
            {
                await db.SaveChangesAsync();
            }
            catch (Exception)
            {
                return BadRequest("Update Token Fail");
            }

            if (!string.IsNullOrWhiteSpace(getMember.Email))
            {
                try
                {
                    await _emailService.SendOtpEmailAsync(getMember.Email, otp);
                }
                catch { }
            }

            return Ok(new
            {
                SuccessToken = getMember.SuccessToken,
                Email = getMember.Email,
                OTP = otp,
                OtpCreated = getMember.OTPCreated
            });
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> RegisterMember(RegisterMember registerMemberParam)
        {
            try
            {
                var phoneNumber = GeneralFunction.NormalizePhoneNumber(registerMemberParam.PhoneNumber);
                if (phoneNumber == null)
                {
                    return BadRequest("The input must be a valid phone number starting with 0.[Example 0123456789 or 01123456789]");
                }
                if (string.IsNullOrEmpty(registerMemberParam.Password))
                {
                    return BadRequest("Password is required.");
                }

                Member member = new Member();
                var checkrepeat = db.Members
                    .Where(x => (registerMemberParam.Email != null && x.Email == registerMemberParam.Email) || x.PhoneNumber == phoneNumber)
                    .FirstOrDefault();
                if (checkrepeat != null)
                {
                    return BadRequest($"Same email or phone number with other member");
                }

                member.MemberGUID = "Member-" + Guid.NewGuid().ToString();
                member.FirstLogin = true;

                member.Password =encoder.Encode(registerMemberParam.Password);
                member.Name = registerMemberParam.Name;
                member.AccountStatus = AccountStatus.Active;
                member.Email = registerMemberParam.Email;
                member.Point = 0;
                if (registerMemberParam.Image != null && registerMemberParam.Image.Length > 0)
                {
                    string filename = Guid.NewGuid() + Path.GetExtension(registerMemberParam.Image.FileName);
                    string uploadFolder = Path.Combine(_iwebhost.WebRootPath, "MemberProfileImage");
                    Directory.CreateDirectory(uploadFolder);
                    string uploadFilePath = Path.Combine(uploadFolder, filename);

                    using (var stream = new FileStream(uploadFilePath, FileMode.Create))
                    {
                        await registerMemberParam.Image.CopyToAsync(stream);
                    }
                    // Optionally, you can store the file path in the TemplateContent object
                    member.Image = filename;
                }
                //member.EmailSubcribe = registerMemberParam.EmailSubcribe;
                member.PhoneNumber = phoneNumber;
                member.BirthDate = registerMemberParam.Birthday;
                member.NotificationStatus = true;
                member.RegisterTime = DateTime.Now;

                string code = "";
                var check = true;
                while (check)
                {
                    code = RandomString(5);
                    check = db.Members.Any(x => x.ReferralCode == code);
                }
                member.ReferralCode = code;

                //Token
                var jwt = _configuration.GetSection("Jwt").Get<Jwt>();
                var claim = new[] {
                    new Claim(JwtRegisteredClaimNames.Sub,_configuration["Jwt:Subject"]),
                    new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
                    new Claim("MemberGUID",member.MemberGUID.ToString()),
                     new Claim(ClaimTypes.Role, "Member")
                    };
               
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key));
                var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                var token = new JwtSecurityToken(
                     jwt.Issuer,
                        jwt.Audience,
                    claim,
                    expires: DateTime.UtcNow.AddMonths(1),
                    signingCredentials: signIn
                    );
                var refreshtoken = new JwtSecurityToken(
                  jwt.Issuer,
                  //jwt.Audience, refreshclaims,
                  expires: DateTime.UtcNow.AddMonths(1),
                  signingCredentials: signIn);

                member.SuccessToken = new JwtSecurityTokenHandler().WriteToken(token);


                db.Members.Add(member);
                db.SaveChanges();
                return Ok(member);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [AllowAnonymous]
        [HttpGet("{email}")]
        public async Task<ActionResult> GenerateMailOTP(string email)
        {
            var finduser = db.Members.Where(x => x.Email == email).FirstOrDefault();
            if (finduser == null)
            {
                return NotFound();
            }

            // No e-mail is sent: the OTP is returned in the response.
            var otp = Random.Shared.Next(100000, 999999).ToString();
            finduser.OTP = otp;
            finduser.OTPCreated = GeneralFunction.GetCurrentMalaysiaDateTime();
            try
            {
                await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

            bool emailSent = false;
            try
            {
                await _emailService.SendOtpEmailAsync(email, otp);
                emailSent = true;
            }
            catch { }

            return Ok(new
            {
                Message = emailSent ? $"OTP sent to {email} successfully." : "OTP generated successfully.",
                Email = email,
                EmailSent = emailSent,
                OTP = otp,
                OtpCreated = finduser.OTPCreated
            });
        }
        [NonAction]
        public static string RandomString(int length)
        {
            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        [HttpPost]
        public async Task<ActionResult<Member>> FindMemberDetails()
        {
            var member = db.Members.Where(x => x.MemberGUID == User.FindFirstValue("MemberGUID")).FirstOrDefault();
            if (member == null)
            {
                return NotFound("Member Not Found");
            }
            return member;
        }
        [HttpPost]
        public async Task<IActionResult> MemberUpdateProfile(UpdateMember EditMember)
        {
            try
            {
                var findMember = db.Members.FirstOrDefault(x => x.MemberGUID == User.FindFirstValue("MemberGUID"));
                if (findMember != null)
                {
                    //findMember.MemberID = EditMember.MemberID;
                    //findMember.Tier = EditMember.Tier;
                    findMember.Email = EditMember.Email;
                    //findMember.RegisterTime = EditMember.RegisterTime;
                    //findMember.NotificationStatus = EditMember.NotificationStatus;
                    //findMember.AccountStatus = EditMember.AccountStatus;
                    //findMember.Email = EditMember.Email;
                    //findMember.PhoneNumber = EditMember.PhoneNumber;
                    findMember.Name = EditMember.Name;
                    
                    if (EditMember.Image != null && EditMember.Image.Length > 0)
                    {
                        string filename = Guid.NewGuid() + Path.GetExtension(EditMember.Image.FileName);
                        string uploadFolder = Path.Combine(_iwebhost.WebRootPath, "MemberProfileImage");
                        Directory.CreateDirectory(uploadFolder);
                        string uploadFilePath = Path.Combine(uploadFolder, filename);

                        using (var stream = new FileStream(uploadFilePath, FileMode.Create))
                        {
                            await EditMember.Image.CopyToAsync(stream);
                        }

                        // Optionally, you can store the file path in the TemplateContent object
                        findMember.Image = filename;
                    }
                    // findMember.Msg = "Edit Successful";
                    
                    await db.SaveChangesAsync();
                    return Ok(findMember);
                }
                else
                {
                    return BadRequest("Member Id Doesn't Exist");
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

    }
}
