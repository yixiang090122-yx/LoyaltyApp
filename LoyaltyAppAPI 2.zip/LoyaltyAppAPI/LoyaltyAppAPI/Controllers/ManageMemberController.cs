﻿using LoyaltyAppAPI.DTO.Member;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Text.RegularExpressions;
using System.Text;
using LoyaltyAppAPI.Configurations;
using LoyaltyAppAPI.DTO;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Scrypt;
using System;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Admin")]
    [Tags("Admin - Manage Members")]
    [ApiController]
    [Authorize]
    public class ManageMemberController : ControllerBase
    {
        private readonly AppDbContext db;
        private IConfiguration _configuration;
        ScryptEncoder encoder = new ScryptEncoder();
        public ManageMemberController(AppDbContext context, IConfiguration configuration)
        {
            db = context;
            _configuration = configuration;
        }
        [HttpGet]
        public async Task<IEnumerable<Member>> GetAllMember()
        {
            return await db.Members.ToListAsync();
        }
        [HttpGet]
        public async Task<ActionResult<Member>> FindMemberById(int id)
        {
            var member = await db.Members.FindAsync(id);
            if (member == null)
            {
                return NotFound($"Member Not Found With Id: {id}");
            }
            return member;
        }


        

        [HttpGet("{email}")]
        public async Task<ActionResult<Member>> FindMemberByEmail(string email)
        {
            var member = await db.Members.FirstOrDefaultAsync(x => x.Email == email);
            if (member == null)
            {
                return NotFound($"Member Not Found With Email: {email}");
            }
            return member;
        }


        [HttpPost]

        public async Task<ActionResult<Member>> CreateMember(Member newmember)
        {
            try
            {
                var getEmail = db.Members.FirstOrDefault(e => e.Email == newmember.Email);
                if (getEmail != null)
                {
                    return BadRequest($"Member For Email {newmember.Email} Is Already Existed");
                }
                var phoneNumber = GeneralFunction.NormalizePhoneNumber(newmember.PhoneNumber);
                if (phoneNumber == null)
                {
                    return BadRequest("The input must be a valid phone number starting with 0.[Example 0123456789 or 01123456789]");
                }
                newmember.PhoneNumber = phoneNumber;

                var getPhoneNumber = db.Members.FirstOrDefault(e => e.PhoneNumber == newmember.PhoneNumber);
                if (getPhoneNumber != null)
                {
                    return BadRequest($"Member For Phone Number {newmember.PhoneNumber} Is Already Existed");
                }


                var RandomMemberGUID = "Member-" + Guid.NewGuid();

                var emailRepeat = db.Members.Where(x => x.Email == newmember.Email).FirstOrDefault();
                var phoneRepeat = db.Members.Where(x => x.PhoneNumber == newmember.PhoneNumber).FirstOrDefault();
                if (emailRepeat != null)
                {
                    return BadRequest($"Member For Email {newmember.Email} Is Already Existed");
                }

                if (phoneRepeat != null)
                {
                    return BadRequest($"Member For Phone Number {newmember.PhoneNumber} Is Already Existed");

                }

                var con = true;
                string RandomReferralCode = "";

                while (con)
                {
                    Random random = new Random();
                    StringBuilder sb = new StringBuilder();

                    const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

                    for (int i = 0; i < 5; i++)
                    {
                        int index = random.Next(chars.Length);
                        sb.Append(chars[index]);
                    }

                    RandomReferralCode = sb.ToString();

                    var checkrepeat = db.Members.Where(x => x.ReferralCode == RandomReferralCode).FirstOrDefault();

                    if (checkrepeat == null)
                    {
                        con = false;
                    }
                    else
                    {
                        continue;
                    }
                }

                string dateString = newmember.BirthDate;
                string pattern = @"^\d{4}-\d{2}-\d{2}$";

                if (Regex.IsMatch(dateString, pattern))
                {
                    //string[] dob = dateString.Split('-');
                    //DateTime getDOB = new DateTime(Convert.ToInt32(dob[0]), Convert.ToInt32(dob[1]), Convert.ToInt32(dob[2]));

                    //// Unix epoch start time (January 1, 1970)
                    //DateTime epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

                    //// Calculate milliseconds since epoch
                    //long currentTimeMillis = (long)(getDOB.ToUniversalTime() - epoch).TotalMilliseconds;
                    //newmember.DOB = currentTimeMillis;
                    // Date string matches the expected format
                    // Proceed with further processing
                    newmember.MemberGUID = RandomMemberGUID;
                    newmember.FirstLogin = true;
                    newmember.EmailSubcribe = false;
                    newmember.NotificationStatus = false;
                    newmember.AccountStatus = AccountStatus.Active;
                    newmember.RegisterTime = DateTime.Now;
                    newmember.Password = encoder.Encode(newmember.Password);
                    newmember.Point = 0;
                    db.Members.Add(newmember);


                    await db.SaveChangesAsync();

                    return Ok(newmember);

                }
                else
                {
                    // Date string does not match the expected format
                    // Handle the error scenario
                    return BadRequest("Please Follow Format xxxx-xx-xx for Birthdate");
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex);

            }
        }

        [HttpPost]

        public ActionResult<Member> EditMember(Member member)
        {
            try
            {
                var findmember = db.Members.FirstOrDefault(x => x.MemberID == member.MemberID);
                if (findmember == null)
                {
                    return NotFound($"Member Not Found With Id: {member.MemberID}");
                }
                else
                {
                    var emailcheck = db.Members.Where(x => member.Email != null && x.Email == member.Email && x.MemberID != findmember.MemberID).FirstOrDefault();
                    if (emailcheck == null)
                    {
                        if (member.PhoneNumber != null)
                        {
                            var phoneNumber = GeneralFunction.NormalizePhoneNumber(member.PhoneNumber);
                            if (phoneNumber == null)
                            {
                                return BadRequest("The input must be a valid phone number starting with 0.[Example 0123456789 or 01123456789]");
                            }
                            if (db.Members.Any(x => x.PhoneNumber == phoneNumber && x.MemberID != findmember.MemberID))
                            {
                                return BadRequest($"Member For Phone Number {phoneNumber} Is Already Existed");
                            }
                            member.PhoneNumber = phoneNumber;
                        }

                        findmember.MemberGUID = member.MemberGUID ?? findmember.MemberGUID;
                        findmember.Name = member.Name ?? findmember.Name;
                        findmember.Email = member.Email ?? findmember.Email;
                        findmember.PhoneNumber = member.PhoneNumber ?? findmember.PhoneNumber;
                        findmember.BirthDate = member.BirthDate ?? findmember.BirthDate;
                        findmember.ReferralBy = member.ReferralBy ?? findmember.ReferralBy;
                      
                        findmember.Tier = member.Tier ?? findmember.Tier;
                        findmember.FirstLogin = member.FirstLogin ?? findmember.FirstLogin;
                        findmember.EmailSubcribe = member.EmailSubcribe ?? findmember.EmailSubcribe;
                        findmember.NotificationStatus = member.NotificationStatus ?? findmember.NotificationStatus;
                        findmember.AccountStatus = member.AccountStatus ?? findmember.AccountStatus;
                        findmember.RegisterTime = member.RegisterTime ?? findmember.RegisterTime;
                        findmember.DeviceId = member.DeviceId ?? findmember.DeviceId;
                        findmember.OTP = member.OTP;
                        findmember.OTPCreated = member.OTPCreated;
                        
                        try
                        {
                            db.SaveChanges();
                        }
                        catch (Exception ex)
                        {
                            return BadRequest("Update Fail:" + ex.Message);
                        }
                        return Ok(findmember);
                    }
                    else
                    {
                        return BadRequest($"Member For Email {member.Email} Is Already Existed");
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpGet("{email}")]
        public async Task<ActionResult> GenerateMailOTP(string email)
        {
            var finduser = db.Members.Where(x => x.Email == email).FirstOrDefault();
            if (finduser == null)
            {
                return NotFound();
            }

            // No e-mail is sent: the OTP is returned in the response.
            var otp = Random.Shared.Next(100000, 999999).ToString();
            finduser.OTP = otp;
            finduser.OTPCreated = GeneralFunction.GetCurrentMalaysiaDateTime();
            try
            {
                await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

            return Ok(new
            {
                Email = email,
                OTP = otp,
                OtpCreated = finduser.OTPCreated
            });
        }

        [HttpPost]
        public IActionResult ActiveOrDeactiveMember(FindMember member)
        {
            var getMember = db.Members.FirstOrDefault(e => e.MemberID == member.MemberID);
            if (getMember == null)
            {
                return BadRequest("Member Not Found");
            }
            if (getMember.AccountStatus == AccountStatus.Active)
            {
                getMember.AccountStatus = AccountStatus.Inactive;
                db.SaveChanges();
                return Ok("Update Successful.");
            }
            else
            {
                getMember.AccountStatus = AccountStatus.Active;
                db.SaveChanges();
                return Ok("Update Successful.");
            }

        }
      
    }
}
