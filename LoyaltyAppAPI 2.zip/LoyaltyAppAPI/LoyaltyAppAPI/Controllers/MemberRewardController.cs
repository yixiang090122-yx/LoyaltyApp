using LoyaltyAppAPI.DTO.Reward;
using LoyaltyAppAPI.DTO.Voucher;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Scrypt;
using System.Security.Claims;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Member")]
    [Tags("Members - Reward")]
    [ApiController]
    public class MemberRewardController : ControllerBase
    {
        private readonly AppDbContext db;
        private IConfiguration _configuration;
        ScryptEncoder encoder = new ScryptEncoder();
        IWebHostEnvironment _iwebhost;
        public MemberRewardController(AppDbContext context, IConfiguration configuration, IWebHostEnvironment iwebhost)
        {
            db = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
        }
        [AllowAnonymous]
        [HttpGet]
        public async Task<IEnumerable<Rewards>> GetAllRewards()
        {
            return await db.Rewards.ToListAsync();
        }

        [AllowAnonymous]
        [HttpGet("{RewardGUID}")]
        public async Task<ActionResult<Rewards>> GetReward(string RewardGUID)
        {
            var rewards = await db.Rewards.FirstOrDefaultAsync(e => e.RewardGUID == RewardGUID);
            if (rewards == null)
            {
                return NotFound($"Not Found With Id: {RewardGUID}");
            }
            return rewards;
        }
        [HttpGet("{RewardGUID}")]
        public async Task<IActionResult> GetAllRewardRecord(string RewardGUID)
        {
            var rewards = await db.RewardRecords.Include(e=>e.Rewards).Include(e=>e.Member)
                .FirstOrDefaultAsync(e => e.Rewards.RewardGUID == RewardGUID
                && e.Member.MemberGUID== User.FindFirstValue("MemberGUID"));
            if (rewards == null)
            {
                return Ok("This Member Can Redeem");
            }
            return BadRequest("Claim Already");
        }

        [HttpPost]
        public async Task<IActionResult> RedeemReward(RedeemReward redeemReward)
        {
            var reward = await db.Rewards.FirstOrDefaultAsync(e => e.RewardGUID == redeemReward.RewardGUID);
            if (reward == null)
            {
                return NotFound($"Not Found With Id: {redeemReward.RewardGUID}");
            }

            var getmember = await db.Members.FirstOrDefaultAsync(e => e.MemberGUID == User.FindFirstValue("MemberGUID"));
            if(getmember==null)
            {
                return BadRequest("Member Not Found");
            }

            try
            {
                if (!encoder.Compare(redeemReward.MemberPassword, getmember.Password))
                {
                    return BadRequest("Wrong Member Password");
                }
            }
            catch
            {
                return BadRequest("Compare Error");
            }

            var getOutletStaff = await db.OutletStaffs
                .FirstOrDefaultAsync(e => e.Pin == redeemReward.OutletStaffPin);
            if(getOutletStaff==null)
            {
                return BadRequest("Wrong Outlet Staff Pin");
            }
            if (reward.ExpireDate.HasValue && reward.ExpireDate.Value < DateTime.Now)
            {
                return BadRequest("Reward Expired");
            }
            if (await db.RewardRecords.AnyAsync(e => e.RewardsID == reward.RewardsID && e.MemberID == getmember.MemberID && e.Claim == true))
            {
                return BadRequest("Claim Already");
            }
            if ((getmember.Point ?? 0) < (reward.Point ?? 0))
            {
                return BadRequest("Not Enough Points");
            }
            long currentTimeMillis = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            RewardRecord record = new RewardRecord()
            {
                RewardRecordGUID = "RewardRecord-" + Guid.NewGuid().ToString(),
                MemberID = getmember.MemberID,
                RewardsID = reward.RewardsID,
                OutletStaffID = getOutletStaff.OutletStaffID,
                Claim = true,
                MemberRedeemDateTime = currentTimeMillis
            };
            getmember.Point = getmember.Point - reward.Point;
            db.RewardRecords.Add(record);
            db.SaveChanges();
            return Ok("Reward Records Created Successful.");
        }

    }
}
