﻿using LoyaltyAppAPI.DTO.Outlet;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Admin")]
    [Tags("Admin - Manage Outlet Staff")]
    [ApiController]
    [Authorize]
    public class OutletStaffController : ControllerBase
    {
        private readonly AppDbContext db;

        public OutletStaffController(AppDbContext context)
        {
            db = context;
        }

        [HttpPost]
        public async Task<ActionResult<IEnumerable<OutletStaff>>> GetAllOutletStaff(GetOutlet outlet)
        {
            if (db.OutletStaffs == null)
            {
                return NotFound();
            }
            return await db.OutletStaffs.Include(e => e.Outlet)
                .Where(e => e.OutletID == outlet.OutletID).ToListAsync();
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<OutletStaff>> GetOutletStaff(int id)
        {
            if (db.OutletStaffs == null)
            {
                return NotFound();
            }
            var users = await db.OutletStaffs.FindAsync(id);

            if (users == null)
            {
                return NotFound();
            }

            return users;
        }

        [HttpPost]
        public async Task<IActionResult> UpdateOutletStaff(OutletStaff staff)
        {
          
            var getBranchStaff = db.OutletStaffs.FirstOrDefault(e => e.OutletStaffID != staff.OutletStaffID && e.Pin == staff.Pin && e.OutletID == staff.OutletID);
            if (getBranchStaff != null)
            {
                return BadRequest("Pin already exists. Please Try Again.");
            }
            var getStaffName = db.OutletStaffs.FirstOrDefault(e => e.OutletStaffID != staff.OutletStaffID && e.OutletStaffName == staff.OutletStaffName && e.OutletID == staff.OutletID);
            if (getStaffName != null)
            {
                return BadRequest("Staff Name already exsists. Please Try Again");
            }
            if (staff.Pin.Length != 6)
            {
                return BadRequest("Invalid PIN. Please enter a 6-digit PIN.");
            }
            db.Entry(staff).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return BadRequest("Update Fail :" + ex.Message);
            }

            return Ok("Staff Updated Successful.");
        }

        [HttpPost]
        public async Task<ActionResult<OutletStaff>> CreateOutletStaff(OutletStaff staff)
        {
            if (db.OutletStaffs == null)
            {
                return Problem("Entity set 'AppDbContext.BranchStaff'  is null.");
            }
            var getBranchStaff = db.OutletStaffs.FirstOrDefault(e => e.Pin == staff.Pin && e.OutletID == staff.OutletID);
            if (getBranchStaff != null)
            {
                return BadRequest("Pin already exists. Please try again.");
            }
            var getStaffName = db.OutletStaffs.FirstOrDefault(e => e.OutletStaffName == staff.OutletStaffName && e.OutletID == staff.OutletID);
            if (getStaffName != null)
            {
                return BadRequest("Staff Name already exsists. Please Try Again");
            }

            if (staff.Pin.Length != 6)
            {
                return BadRequest("Invalid PIN. Please enter a 6-digit PIN.");
            }

            try
            {
                db.OutletStaffs.Add(staff);
                await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return BadRequest("Created Fail:" + ex.Message);
            }

            return Ok("Created Successful");
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOutletStaff(int id)
        {
            if (db.OutletStaffs == null)
            {
                return NotFound();
            }
            var staff = await db.OutletStaffs.FindAsync(id);
            if (staff == null)
            {
                return NotFound();
            }

            db.OutletStaffs.Remove(staff);
            try
            {
                await db.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return BadRequest("Delete Outlet Staff Fail:" + ex.Message);
            }

            return Ok("Deleted Successful.");
        }



    }
}
