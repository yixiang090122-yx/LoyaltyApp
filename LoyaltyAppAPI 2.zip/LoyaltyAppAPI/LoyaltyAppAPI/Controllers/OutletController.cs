﻿using LoyaltyAppAPI.DTO.Outlet;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Admin")]
    [Tags("Admin - Manage Outlet")]
    [ApiController]
    [Authorize]
    public class OutletController : ControllerBase
    {
        private readonly AppDbContext db;

        public OutletController(AppDbContext context)
        {
            db = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Outlet>>> GetAllOutlets()
        {
            if (db.Outlets == null)
            {
                return NotFound();
            }
            return await db.Outlets.ToListAsync();
        }

        [HttpPost]
        public async Task<ActionResult<Outlet>> GetOutlet(GetOutlet outlet)
        {
            if (db.Outlets == null)
            {
                return NotFound();
            }
            var getOutlets = await db.Outlets
                .FirstOrDefaultAsync(e => e.OutletID == outlet.OutletID);

            if (getOutlets == null)
            {
                return NotFound();
            }

            return getOutlets;
        }

        [HttpPost]
        public async Task<ActionResult<Outlet>> PostOutlet(GetOutlet outlet)
        {
            if (db.Outlets == null)
            {
                return Problem("Entity set 'AppDbContext.Branches'  is null.");
            }
            var checkDuplicate = await db.Outlets
                .FirstOrDefaultAsync(e => e.OutletName == outlet.OutletName);

            if (checkDuplicate != null)
            {
                return BadRequest("Outlet Name Duplicate");
            }
            if (outlet.OutletName == null)
            {
                return BadRequest("Outlet Name cannot be empty.");
            }

            Outlet CreateOutlet = new Outlet()
            {
                OutletName = outlet.OutletName,
                CreatedDate = GeneralFunction.GetCurrentMalaysiaDateTime(),
                OutletGUID=Guid.NewGuid().ToString(),
                OutletStatus = OutletStatus.Active,
            };

            db.Outlets.Add(CreateOutlet);
            await db.SaveChangesAsync();

            return Ok(CreateOutlet);
        }

        [HttpGet("{OutletID}")]
        public async Task<IActionResult> ActiveOrDeactiveOutlet(int OutletID)
        {
            if (db.Outlets == null)
            {
                return BadRequest();
            }
            var Branches = await db.Outlets.FindAsync(OutletID);
            if (Branches == null)
            {
                return BadRequest("Outlet Not Found");
            }
            if (Branches.OutletStatus == OutletStatus.Active)
            {
                Branches.OutletStatus = OutletStatus.Deactive;
            }
            else if (Branches.OutletStatus == OutletStatus.Deactive)
            {
                Branches.OutletStatus = OutletStatus.Active;
            }
            try
            {
                await db.SaveChangesAsync();
            }
           catch(Exception ex)
            {
                return BadRequest("Update Fail:"+ex.Message);
            }

            return Ok("Update Successful");
        }
    }
}
