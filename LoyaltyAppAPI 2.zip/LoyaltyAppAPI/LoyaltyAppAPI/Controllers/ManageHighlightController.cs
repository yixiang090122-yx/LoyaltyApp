﻿using LoyaltyAppAPI.DTO.Highlight;
using LoyaltyAppAPI.Migrations;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Scrypt;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Tags("Admin - Manage Highlights")]
    [Authorize(Roles = "Admin")]
    [ApiController]
    [Authorize]
    public class ManageHighlightController : ControllerBase
    {
        private readonly AppDbContext db;
        private IConfiguration _configuration;
        ScryptEncoder encoder = new ScryptEncoder();
        IWebHostEnvironment _iwebhost;
        public ManageHighlightController(AppDbContext context, IWebHostEnvironment iwebhost)
        {
            db = context;
            _iwebhost = iwebhost;
        }

        [HttpGet]
        public async Task<IEnumerable<Highlight>> GetAllHighlight()
        {
            return await db.Highlights.OrderByDescending(x => x.CreateDate).ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Highlight>> GetHighlight(int id)
        {
            var highlight = await db.Highlights.FirstOrDefaultAsync(e => e.HighlightID == id);
            if (highlight == null)
            {
                return NotFound();
            }
            return highlight;
        }
       

        [HttpPost]
        public async Task<ActionResult> CreateHighlight([FromForm] CreateHighlight highlight, [FromForm] IFormFile file)
        {
            try
            {
                Highlight highlight1 = new Highlight();
                if (file != null && file.Length > 0)
                {
                    string filename = Guid.NewGuid() + Path.GetExtension(file.FileName);
                    string uploadFilePath = Path.Combine(_iwebhost.WebRootPath, "MerchantHighlight", filename);

                    using (var stream = new FileStream(uploadFilePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    // Optionally, you can store the file path in the TemplateContent object
                    highlight.Image = filename;
                }
                highlight1.Image = highlight.Image;
                highlight1.HighlightGUID = "Highlight-" + Guid.NewGuid();
                highlight1.Title = highlight.Title;
                highlight1.SubTitle = highlight.SubTitle;
                highlight1.Description = highlight.Description;

                highlight1.TnC = highlight.TnC;
                highlight1.CreateDate = highlight.CreateDate;
                highlight1.ExpireDate = highlight.ExpireDate;

                if(highlight1.ExpireDate >= DateTime.Now)
                {
                    highlight1.Status = "Active";
                }
                else
                {
                    highlight1.Status = "Deactive";
                }
             
                
                db.Add(highlight1);
                await db.SaveChangesAsync();
                return Ok(highlight1);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex); // For demonstration purposes only, replace with actual logging
                return StatusCode(500, "An internal server error occurred. Please try again later.");
            }
        }

        [HttpPost]
        public async Task<ActionResult<Highlight>> EditHighlight([FromForm] CreateHighlight highlight, [FromForm] IFormFile? file)
        {
            try
            {
                var findhightlight = db.Highlights.FirstOrDefault(x => x.HighlightID == highlight.HighlightID);
                if (findhightlight == null)
                {
                    return BadRequest();
                }
                else
                {

                    if (file != null && file.Length > 0)
                    {
                        string filename = Guid.NewGuid() + Path.GetExtension(file.FileName);
                        string uploadFilePath = Path.Combine(_iwebhost.WebRootPath, "MerchantHighlight", filename);

                        using (var stream = new FileStream(uploadFilePath, FileMode.Create))
                        {
                            await file.CopyToAsync(stream);
                        }

                        // Optionally, you can store the file path in the TemplateContent object
                        findhightlight.Image = filename;
                    }

                    findhightlight.Title = highlight.Title;
                    findhightlight.SubTitle = highlight.SubTitle;
                    findhightlight.Description = highlight.Description;
                    findhightlight.TnC = highlight.TnC;
                    findhightlight.CreateDate = highlight.CreateDate;
                    findhightlight.ExpireDate = highlight.ExpireDate;

                    if (findhightlight.ExpireDate >= DateTime.Now)
                    {
                        findhightlight.Status = "Active";
                    }
                    else
                    {
                        findhightlight.Status = "Deactive";
                    }
                    await db.SaveChangesAsync();
                    return Ok(findhightlight);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}")]
        public async Task<ActionResult> DeleteHighlight(int id)
        {
            var getHighlight = await db.Highlights.FirstOrDefaultAsync(e => e.HighlightID == id);
            db.Highlights.Remove(getHighlight);
            try
            {

                await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return BadRequest("Delete Highlight Fail:" + ex.Message);
            }

            return Ok("Deleted Highlight Successful");
        }
    }
}
