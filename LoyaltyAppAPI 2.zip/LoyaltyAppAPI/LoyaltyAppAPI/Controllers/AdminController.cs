﻿using LoyaltyAppAPI.Configurations;
using LoyaltyAppAPI.DTO;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Scrypt;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Admin")]

    [ApiController]
    [Authorize]
    public class AdminController : ControllerBase
    {
        private readonly AppDbContext db;
        private IConfiguration _configuration;
        ScryptEncoder encoder = new ScryptEncoder();
        public AdminController(IConfiguration configuration, AppDbContext context)
        {
            db = context;
            _configuration = configuration;
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> AdminLogin([FromBody] TokenDTO userInfo)
        {
            if (userInfo == null || string.IsNullOrEmpty(userInfo.Username) || string.IsNullOrEmpty(userInfo.Password))
            {
                return BadRequest("Token generation failed:Username or Password is missing.");
            }

            var user = await GetAdmin(userInfo.Username, userInfo.Password);
            if (user == null)
            {
                return Unauthorized("Invalid username or password.");
            }
            var jwt = _configuration.GetSection("Jwt").Get<Jwt>();
            var claim = new[] {
                    new Claim(JwtRegisteredClaimNames.Sub,_configuration["Jwt:Subject"]),
                    new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
                    new Claim("AdminID",user.AdminID.ToString()),
                     new Claim(ClaimTypes.Role, "Admin")
                    };
            var refreshclaims = new[]
               {
                    new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim("AdminID", user.AdminID.ToString()),
                    new Claim(ClaimTypes.Role, "Admin")
                };
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key));
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                 jwt.Issuer,
                    jwt.Audience,
                claim,
                expires: DateTime.Now.AddDays(1),
                signingCredentials: signIn
                );
            var refreshtoken = new JwtSecurityToken(
              jwt.Issuer,
              jwt.Audience, refreshclaims,
              expires: DateTime.UtcNow.AddMonths(1),
              signingCredentials: signIn);

            user.SuccessToken = new JwtSecurityTokenHandler().WriteToken(token);
            user.RefreshToken = new JwtSecurityTokenHandler().WriteToken(refreshtoken);
            user.TokenMinutes = "1440"; // 1天的分钟数
            try
            {
                db.Admins.Update(user);
                await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return BadRequest("Update Token Fail");
            }
            return Ok(new Admin
            {
                AdminID = user.AdminID,
                SuccessToken = user.SuccessToken,
                RefreshToken = user.RefreshToken,
                TokenMinutes = user.TokenMinutes
            });
        }
        //[AllowAnonymous]
        //[HttpPost]
        //public IActionResult InitializeAdmin(Admin admin)
        //{
        //    admin.Password = encoder.Encode(admin.Password);
        //    db.Add(admin);
        //    db.SaveChanges();
        //    return Ok("Admin Created Successful");
        //}

        [NonAction]
        public async Task<Admin> GetAdmin(string Username, string Password)
        {
            var getAdmin = await db.Admins.Where(e => e.Username == Username).FirstOrDefaultAsync();
            if (getAdmin == null || !getAdmin.Password.Equals(Password))
            {
                return null;
            }

            return getAdmin;
        }

        //[HttpPost]
        //public async Task<IActionResult> SuperAdminLogin(TokenDTO admin)
        //{
        //    var findAdmin = await db.Admins.FirstOrDefaultAsync(e => e.Username == admin.Username && e.Password == admin.Password);
        //    if (findAdmin == null)
        //    {
        //        return BadRequest("Incorrect Username and Password");
        //    }

        //    return Ok(findAdmin);
        //}

       
    }
}
