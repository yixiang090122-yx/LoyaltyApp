﻿using LoyaltyAppAPI.DTO.History;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Scrypt;
using System.Security.Claims;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Member")]
    [Tags("Members - History")]
    [ApiController]
    [Authorize]
    public class MemberHistoryController : Controller
    {
        ScryptEncoder encoder = new ScryptEncoder();

        private readonly AppDbContext db;
        private IConfiguration _configuration;
        IWebHostEnvironment _iwebhost;

        public MemberHistoryController(AppDbContext context, IConfiguration configuration, IWebHostEnvironment iwebhost)
        {
            db = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
        }

        [HttpGet]
        public async Task<IActionResult> GetHistoryRecord(DateRange? dateRange = DateRange.All, string? types = null)
        {
            var member = await db.Members.FirstOrDefaultAsync(m => m.MemberGUID == User.FindFirstValue("MemberGUID"));

            if (member == null)
            {
                return BadRequest("Member not found");
            }

            var voucher_record = await db.VoucherRecords.Where(p => p.MemberID == member.MemberID).ToListAsync();
            var reward_record = await db.RewardRecords.Where(p => p.MemberID == member.MemberID).Include(x => x.Rewards).ToListAsync();
            var point_record = await db.PointRecords.Where(p => p.MemberID == member.MemberID).ToListAsync();
            var vouchers = await db.Vouchers.ToListAsync();
            var rewards = await db.Rewards.ToListAsync();

            var historyService = new HistoryService(
                voucher_record,
                reward_record,
                point_record,
                vouchers,
                rewards
                );

            List<HistoryType> typeList = new();
            if (!string.IsNullOrEmpty(types))
            {
                typeList = types.Split(',')
                                .Select(t => Enum.TryParse<HistoryType>(t, true, out var result) ? result : (HistoryType?)null)
                                .Where(t => t.HasValue)
                                .Select(t => t.Value)
                                .ToList();
            }
            else
            {
                typeList = new List<HistoryType> { HistoryType.Reward, HistoryType.Point, HistoryType.Voucher };
            }

            var filtered_history = historyService.GetHistoryRecords(dateRange: dateRange, types: typeList);

            return Ok(filtered_history);
        }
    }
}
