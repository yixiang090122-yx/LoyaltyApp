using LoyaltyAppAPI.DTO.Outlet;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Scrypt;
using System.Security.Claims;

namespace LoyaltyAppAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [Authorize(Roles = "Member")]
    [Tags("Members - Outlet")]
    [ApiController]
    public class MemberOutletController : ControllerBase
    {
        private readonly AppDbContext db;
        private IConfiguration _configuration;
        ScryptEncoder encoder = new ScryptEncoder();
        IWebHostEnvironment _iwebhost;
        public MemberOutletController(AppDbContext context, IConfiguration configuration, IWebHostEnvironment iwebhost)
        {
            db = context;
            _configuration = configuration;
            _iwebhost = iwebhost;
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Outlet>>> GetAllOutlets()
        {
            if (db.Outlets == null)
            {
                return NotFound();
            }
            return await db.Outlets.ToListAsync();
        }
        [AllowAnonymous]
        [HttpGet("{OutletGUID}")]
        public async Task<ActionResult<Outlet>> GetOutlet(string OutletGUID)
        {
            if (db.Outlets == null)
            {
                return NotFound();
            }
            var getOutlets = await db.Outlets
                .FirstOrDefaultAsync(e => e.OutletGUID == OutletGUID);

            if (getOutlets == null)
            {
                return NotFound();
            }

            return getOutlets;
        }



    }
}
