using System.Net;
using System.Net.Mail;

namespace LoyaltyAppAPI.Services
{
    public class EmailService : IEmailService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<EmailService> _logger;

        public EmailService(IConfiguration configuration, ILogger<EmailService> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public async Task SendEmailAsync(string toEmail, string subject, string htmlBody)
        {
            try
            {
                var host = _configuration["Smtp:Host"] ?? "smtp.gmail.com";
                var port = int.Parse(_configuration["Smtp:Port"] ?? "587");
                var senderEmail = _configuration["Smtp:SenderEmail"] ?? "kiraleong2024@gmail.com";
                var senderName = _configuration["Smtp:SenderName"] ?? "Loyalty App System";
                var password = _configuration["Smtp:Password"] ?? "frschnprmqhqonmv";

                using var client = new SmtpClient(host, port)
                {
                    Credentials = new NetworkCredential(senderEmail, password.Replace(" ", "")),
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false
                };

                using var mailMessage = new MailMessage
                {
                    From = new MailAddress(senderEmail, senderName),
                    Subject = subject,
                    Body = htmlBody,
                    IsBodyHtml = true
                };
                mailMessage.To.Add(toEmail);

                await client.SendMailAsync(mailMessage);
                _logger.LogInformation($"[EmailService] Email successfully sent to {toEmail}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"[EmailService] Failed to send email to {toEmail}: {ex.Message}");
                throw;
            }
        }

        public async Task SendOtpEmailAsync(string toEmail, string otp)
        {
            string subject = "[Loyalty App] 您的验证码 / Verification Code (OTP)";
            string body = $@"
            <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 10px; background-color: #ffffff;'>
                <div style='text-align: center; border-bottom: 2px solid #22c55e; padding-bottom: 15px; margin-bottom: 25px;'>
                    <h2 style='color: #1e293b; margin: 0; font-size: 24px;'>Loyalty App</h2>
                    <p style='color: #64748b; font-size: 14px; margin: 5px 0 0;'>会员服务中心 / Member Services</p>
                </div>
                <p style='font-size: 16px; color: #334155;'>尊敬的会员您好：</p>
                <p style='font-size: 15px; color: #475569; line-height: 1.6;'>
                    您正在进行身份验证（找回密码/安全验证）。您的专属 6 位一次性验证码 (OTP) 如下：
                </p>
                <div style='background-color: #f0fdf4; border: 2px dashed #22c55e; border-radius: 8px; text-align: center; padding: 20px; margin: 25px 0;'>
                    <span style='font-size: 34px; font-weight: 800; letter-spacing: 8px; color: #15803d; font-family: Consolas, monospace;'>{otp}</span>
                </div>
                <p style='font-size: 14px; color: #64748b; line-height: 1.6;'>
                    ⏰ <strong>重要提示</strong>：<br>
                    • 验证码将在 <strong>10 分钟</strong> 后失效，请尽快完成验证。<br>
                    • 为保护您的账户安全，切勿将此验证码透露给任何人。<br>
                    • 若非您本人操作，请忽略此邮件，您的账户依然安全。
                </p>
                <hr style='border: none; border-top: 1px solid #e2e8f0; margin: 30px 0 15px;'>
                <p style='font-size: 12px; color: #94a3b8; text-align: center;'>此邮件由系统自动发送，请勿直接回复。</p>
            </div>";

            await SendEmailAsync(toEmail, subject, body);
        }
    }
}
