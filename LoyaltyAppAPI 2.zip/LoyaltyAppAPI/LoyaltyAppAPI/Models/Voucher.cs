﻿namespace LoyaltyAppAPI.Models
{
    public class Voucher
    {
        public int VoucherID { get; set; }
        public string? VoucherGUID { get; set; }
        public string? VoucherName { get; set; }
        public string? Image { get; set; }
        public string? Title { get; set; }
        public string? Subtitle { get; set; }
        public string? ShortTitle { get; set; }
        public string? Description { get; set; }
        public string? TNC { get; set; }
        public DateTime? VoucherCreatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ExpiredDate { get; set; }
        public string? VoucherStatus { get; set; }
        public List<VoucherRule>? VoucherRules { get; set; }
    }
}

