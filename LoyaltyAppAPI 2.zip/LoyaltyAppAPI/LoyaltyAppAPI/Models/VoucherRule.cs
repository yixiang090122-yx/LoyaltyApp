﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LoyaltyAppAPI.Models
{
    public class VoucherRule
    {
        public int? VoucherRuleID { get; set; }
        public int VoucherID { get; set; }
        public string? DayOfWeek { get; set; }
        public TimeSpan? StartTime { get; set; }
        public TimeSpan? EndTime { get; set; }

        [NotMapped]
        public bool IsEnabled { get; set; }
    }
}
