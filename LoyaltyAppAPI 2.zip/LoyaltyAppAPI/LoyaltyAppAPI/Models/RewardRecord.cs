﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LoyaltyAppAPI.Models
{
    public class RewardRecord
    {
        public int RewardRecordID { get; set; }
        public string? RewardRecordGUID { get; set; }
        public Rewards? Rewards { get; set; }
        [ForeignKey(nameof(Rewards))]
        public int? RewardsID { get; set; }
        public Member? Member { get; set; }
        public int? MemberID { get; set; }
        public OutletStaff? OutletStaff { get; set; }
        public int? OutletStaffID { get; set; }
        public bool? Claim { get; set; }
        public long? MemberRedeemDateTime { get; set; }
    }
}
