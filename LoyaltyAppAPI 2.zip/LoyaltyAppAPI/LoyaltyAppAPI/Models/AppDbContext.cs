﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace LoyaltyAppAPI.Models
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Feedback> Feedbacks { get; set; }
        public DbSet<Highlight> Highlights { get; set; }
        public DbSet<History> Histories { get; set; }
        public DbSet<Member> Members { get; set; }

        public DbSet<Outlet> Outlets { get; set; }
        public DbSet<OutletStaff> OutletStaffs { get; set; }

        public DbSet<PointRecord> PointRecords { get; set; }
        public DbSet<Rewards> Rewards { get; set; }
        public DbSet<RewardRecord> RewardRecords { get; set; }
        public DbSet<Voucher> Vouchers { get; set; }
        public DbSet<VoucherRecord> VoucherRecords { get; set; }
        public DbSet<VoucherRule> VoucherRules { get; set; }









    }
}
