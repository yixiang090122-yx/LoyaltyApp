﻿namespace LoyaltyAppAPI.Models
{
    public class TokenResult
    {
        public string SuccessToken { get; set; }
        public string TokenMinutes { get; set; }
        public string TokenRoles { get; set; }
    }
}
