﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LoyaltyAppAPI.Models
{
    public class OutletStaff
    {
        public int OutletStaffID { get; set; }
        public string? OutletStaffName { get; set; }
        public string? Pin { get; set; }
        public string? Role { get; set; }
        public Outlet? Outlet { get; set; }
        [ForeignKey(nameof(Outlet))]
        public int? OutletID { get; set; }
    }
}
