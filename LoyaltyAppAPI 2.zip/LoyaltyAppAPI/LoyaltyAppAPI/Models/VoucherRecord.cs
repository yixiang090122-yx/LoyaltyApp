﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LoyaltyAppAPI.Models
{
    public class VoucherRecord
    {
        public int VoucherRecordID { get; set; }
        public string? VoucherRecordGUID { get; set; }
        public Voucher? Voucher { get; set; }
        [ForeignKey(nameof(Voucher))]
        public int VoucherID { get; set; }
        public Member? Member { get; set; }
        [ForeignKey(nameof(Member))]
        public int? MemberID { get; set; }
        
        public OutletStaff? OutletStaff { get; set; }
        [ForeignKey(nameof(OutletStaff))]
        public int? OutletStaffID { get; set; }

        public bool? Claim { get; set; }
        public long? MemberRedeemDateTime { get; set; }
    }
}
