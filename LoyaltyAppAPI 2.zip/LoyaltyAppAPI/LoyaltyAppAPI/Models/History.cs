﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LoyaltyAppAPI.Models
{
    public class History
    {
        public int HistoryId { get; set; }
        public string HistoryGUID { get; set; }
        public Member? Member { get; set; }
        [ForeignKey(nameof(Member))]
        public int? MemberID { get; set; }
        public string? Status { get; set; }
        public DateTime DateTime { get; set; }
        public string? ReferenceNumber { get; set; }
        public double? Amount { get; set; }
        public string? Description { get; set; }
        public int? Point { get; set; }
    }
}

public enum HistoryStatus
{
    Pending, Active, Rejected, Failed
}

