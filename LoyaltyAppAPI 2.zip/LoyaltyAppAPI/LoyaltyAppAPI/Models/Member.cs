﻿using System.ComponentModel.DataAnnotations;

namespace LoyaltyAppAPI.Models
{
    public class Member
    {
        public int MemberID { get; set; }
        public string? MemberGUID { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? PhoneNumber { get; set; }
        public string? BirthDate { get; set; }
        public string? ReferralCode { get; set; }
        public string? ReferralBy { get; set; }
        public string? Password { get; set; }
        public string? Tier { get; set; }
        public string? Image { get; set; }
        public bool? FirstLogin { get; set; }
        public bool? EmailSubcribe { get; set; }
        public bool? NotificationStatus { get; set; }
        public AccountStatus? AccountStatus { get; set; }
        public DateTime? RegisterTime { get; set; }
        public string? DeviceId { get; set; }
        public string? OTP { get; set; }
        public DateTime? OTPCreated { get; set; }
        public string? SuccessToken { get; set; }
        public string? TokenMinutes { get; set; }
        public int? Point { get; set; }
    }
}
public enum AccountStatus
{
    Pending,Active,Inactive
}
