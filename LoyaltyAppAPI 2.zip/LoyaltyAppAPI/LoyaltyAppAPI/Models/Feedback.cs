﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LoyaltyAppAPI.Models
{
    public class Feedback
    {
        public int FeedbackID { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public string? Rating { get; set; }
        public string? Category { get; set; }
        [ForeignKey(nameof(Member))]
        public int? MemberID { get; set; }
        public string? MemberGUID { get; set; }
        public string? Location { get; set; }
    }
}
