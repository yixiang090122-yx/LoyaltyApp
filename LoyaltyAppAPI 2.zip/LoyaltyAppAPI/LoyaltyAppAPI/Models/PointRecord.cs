﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LoyaltyAppAPI.Models
{
    public class PointRecord
    {
        public int PointRecordID { get; set; }
        public string PointRecordGUID { get; set; }
        public string? Code { get; set; }
        public int Point { get; set; }
        public Member? Member { get; set; }
        [ForeignKey(nameof(Member))]
        public int? MemberID { get; set; }
        public DateTime DateAssign { get; set; }
        public string? Description { get; set; }
        public OutletStaff? OutletStaff { get; set; }
        [ForeignKey(nameof(OutletStaff))]
        public int? OutletStaffID { get; set; }
        public PointRecordStatus? PointRecordStatus { get; set; }
        public string? Remark { get; set; }
        public string? Image { get; set; }
    }
}

public enum PointRecordStatus
{
    Pending, Approve, Rejected              
}

