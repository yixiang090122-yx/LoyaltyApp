﻿namespace LoyaltyAppAPI.Models
{
    public class Outlet
    {
        public int OutletID { get; set; }
        public string? OutletGUID { get; set; }
        public string? OutletName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public OutletStatus? OutletStatus { get; set; }
    }
}
public enum OutletStatus
{
    Pending, Active, Deactive
}