﻿namespace LoyaltyAppAPI.Models
{
    public class Admin
    {
        public int AdminID { get; set; }
        public string? Username { get; set; }
        public string? Password { get; set; }
        public string? SuccessToken { get; set; }
        public string? RefreshToken { get; set; }
        public string? TokenMinutes { get; set; }
    }
}
