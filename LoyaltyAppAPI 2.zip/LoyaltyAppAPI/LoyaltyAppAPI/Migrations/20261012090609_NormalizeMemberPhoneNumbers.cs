﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoyaltyAppAPI.Migrations
{
    /// <inheritdoc />
    public partial class NormalizeMemberPhoneNumbers : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Store every member phone number as +60123456789 (see GeneralFunction.NormalizePhoneNumber).
            migrationBuilder.Sql("UPDATE Members SET PhoneNumber = '+6' + PhoneNumber WHERE PhoneNumber LIKE '0%'");
            migrationBuilder.Sql("UPDATE Members SET PhoneNumber = '+' + PhoneNumber WHERE PhoneNumber LIKE '60%'");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Data clean-up only; there is nothing to undo.
        }
    }
}
