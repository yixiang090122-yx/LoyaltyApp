﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoyaltyAppAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddRedeem : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ExpiredDate",
                table: "VoucherRecords");

            migrationBuilder.DropColumn(
                name: "MemberCollectDate",
                table: "VoucherRecords");

            migrationBuilder.DropColumn(
                name: "MemberRedeemDate",
                table: "RewardRecords");

            migrationBuilder.AddColumn<long>(
                name: "MemberRedeemDateTime",
                table: "VoucherRecords",
                type: "bigint",
                nullable: true);

            migrationBuilder.AddColumn<long>(
                name: "MemberRedeemDateTime",
                table: "RewardRecords",
                type: "bigint",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MemberRedeemDateTime",
                table: "VoucherRecords");

            migrationBuilder.DropColumn(
                name: "MemberRedeemDateTime",
                table: "RewardRecords");

            migrationBuilder.AddColumn<DateTime>(
                name: "ExpiredDate",
                table: "VoucherRecords",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "MemberCollectDate",
                table: "VoucherRecords",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "MemberRedeemDate",
                table: "RewardRecords",
                type: "datetime2",
                nullable: true);
        }
    }
}
