﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoyaltyAppAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddDate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "VoucherCreatedDate",
                table: "Vouchers",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "RewardCreatedDate",
                table: "Rewards",
                type: "datetime2",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "VoucherCreatedDate",
                table: "Vouchers");

            migrationBuilder.DropColumn(
                name: "RewardCreatedDate",
                table: "Rewards");
        }
    }
}
