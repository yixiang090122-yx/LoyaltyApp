﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoyaltyAppAPI.Migrations
{
    /// <inheritdoc />
    public partial class RemoveMerchantID : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MerchantID",
                table: "Vouchers");

            migrationBuilder.DropColumn(
                name: "MerchantID",
                table: "VoucherRecords");

            migrationBuilder.DropColumn(
                name: "MerchantID",
                table: "Rewards");

            migrationBuilder.DropColumn(
                name: "MerchantID",
                table: "RewardRecords");

            migrationBuilder.DropColumn(
                name: "MerchantID",
                table: "Outlets");

            migrationBuilder.DropColumn(
                name: "MerchantID",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "MerchantId",
                table: "Histories");

            migrationBuilder.DropColumn(
                name: "MerchantID",
                table: "Highlights");

            migrationBuilder.DropColumn(
                name: "MerchantID",
                table: "Feedbacks");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "MerchantID",
                table: "Vouchers",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MerchantID",
                table: "VoucherRecords",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MerchantID",
                table: "Rewards",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MerchantID",
                table: "RewardRecords",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MerchantID",
                table: "Outlets",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MerchantID",
                table: "Members",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "MerchantId",
                table: "Histories",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MerchantID",
                table: "Highlights",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MerchantID",
                table: "Feedbacks",
                type: "int",
                nullable: true);
        }
    }
}
