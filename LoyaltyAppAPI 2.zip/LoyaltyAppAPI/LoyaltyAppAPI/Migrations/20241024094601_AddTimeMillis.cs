﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoyaltyAppAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddTimeMillis : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<long>(
                name: "DOB",
                table: "Members",
                type: "bigint",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DOB",
                table: "Members");
        }
    }
}
