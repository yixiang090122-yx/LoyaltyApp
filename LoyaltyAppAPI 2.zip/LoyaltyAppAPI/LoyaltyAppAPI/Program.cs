using LoyaltyAppAPI.Controllers;
using LoyaltyAppAPI.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

using LoyaltyAppAPI.Services;

var builder = WebApplication.CreateBuilder(args);

// 1. 配置 CORS：允许所有 Origin (包括所有 localhost 端口及线上网站)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.SetIsOriginAllowed(origin => true) // 允许任意域名和任意 localhost 端口
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials(); // 允许携带 Cookie / 身份验证凭证
    });
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

// 注册邮件发送服务
builder.Services.AddScoped<IEmailService, EmailService>();

// 2. 配置 Swagger + JWT 鉴权支持
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "CLM Platform", Version = "v1" });

    // HTTP Bearer 类型：Authorize 窗口只要贴上 token，Swagger 会自动加上 "Bearer "
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "Paste the successToken only. Swagger adds \"Bearer \" for you.",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] { }
        }
    });
});

// 3. 配置 JWT Bearer 认证
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
        };

        // Authorization header 可以只放 token（不写 "Bearer "）；"Bearer <token>" 也照样可以用
        options.Events = new JwtBearerEvents
        {
            OnMessageReceived = context =>
            {
                string authorization = context.Request.Headers.Authorization.ToString();
                if (!string.IsNullOrWhiteSpace(authorization) &&
                    !authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                {
                    context.Token = authorization.Trim();
                }
                return Task.CompletedTask;
            }
        };
    });

// 4. 配置数据库连接
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("LoyatyApp")));

var app = builder.Build();

// 5. HTTP 请求管道配置
if (app.Environment.IsProduction() || app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "CLM API V1");
    });
}

app.UseHttpsRedirection();
app.UseStaticFiles();

// 必须放置在 UseAuthentication 和 UseAuthorization 之前
app.UseCors("AllowAll");

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();