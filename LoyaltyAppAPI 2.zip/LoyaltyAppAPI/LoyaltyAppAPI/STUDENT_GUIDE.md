# Loyalty App API 学生实训与开发对接指南 (Student Guide)

本指南旨在帮助学生快速上手 `LoyaltyAppAPI`，顺畅完成移动端 App 或 Web 前端与后端 API 的对接作业。

---

## 一、 快速起步 (Quick Start)

1. **启动后端服务**：在 Visual Studio 按 `F5`（或终端运行 `dotnet run`）。
2. **打开 Swagger 接口文档**：浏览器访问控制台显示的地址，例如：
   `https://localhost:5104/swagger/index.html`
3. **第一步：一键注入测试基础数据**
   在 Swagger 中找到并执行：
   * **`GET /api/ManageDefault/CreateDefaults`**
   * 点击 **Execute**，系统将自动创建好门店、店员、测试管理员、演示会员、优惠券与礼品！

---

## 二、 预设测试凭证 (Default Credentials)

| 角色 / 场景 | 账号 / 标识 | 密码 / PIN 码 | 说明 |
| :--- | :--- | :--- | :--- |
| **测试会员 (Member)** | 手机号：`0123456789` | 密码：`123456` | 默认带有 **200 积分**，方便立即测试兑换功能 |
| **门店店员 (Outlet Staff)** | 门店：`Main Branch (Mid Valley)` | **PIN 码：`123456`** | 🔑 **关键**：用于前端核销优惠券、兑换礼品或审批积分 |
| **系统管理员 (Admin)** | 用户名：`admin` | 密码：`admin123` | 用于登录管理后台 API |

---

## 三、 5 大核心功能对接流程与示例

### 1. 会员登录 (Login)
* **API**: `POST /api/Member/MemberLogin`
* **Request Body**:
  ```json
  {
    "phoneNumber": "0123456789",
    "password": "123456"
  }
  ```
* **Response**:
  ```json
  {
    "successToken": "eyJhbGciOi...",
    "email": "demo@student.com",
    "otp": "489123",
    "otpCreated": "2026-10-22T..."
  }
  ```
* **注意**：后续所有需要登录的接口，必须在 HTTP Header 中带上：
  `Authorization: Bearer <successToken>`
  *(在 Swagger 页面点击右上角绿色 **Authorize** 按钮贴入该 Token 即可)*

---

### 2. 忘记密码与重置密码 (Forgot / Reset Password)
#### 步骤 2.1：请求发送 OTP 验证码
* **API**: `POST /api/Member/GenerateOTP`
* **Request Body**:
  ```json
  {
    "phoneNumber": "0123456789"
  }
  ```
* **Response**:
  ```json
  {
    "message": "OTP generated and sent to demo@student.com successfully.",
    "phoneNumber": "+60123456789",
    "email": "demo@student.com",
    "emailSent": true,
    "otp": "654321",
    "otpCreated": "2026-10-22T..."
  }
  ```
  *(注：系统已集成 Gmail 真实邮件服务。若会员资料有 Email，系统会自动发送带排版的验证码邮件到该邮箱；同时 Response 中也保留了 OTP 字段，双重保障调试顺利)*

#### 步骤 2.2：提交 OTP 并设置新密码
* **API**: `POST /api/Member/MemberResetPassword`
* **Request Body**:
  ```json
  {
    "phoneNumber": "0123456789",
    "otp": "654321",
    "newPassword": "NewPassword@123"
  }
  ```
* **Response**:
  ```json
  {
    "message": "Password reset successfully."
  }
  ```

---

### 3. 优惠券与到店店员核销 (Vouchers)
#### 步骤 3.1：查看有效优惠券
* **API**: `GET /api/MemberVoucher/ShowVouchers`（支持游客直接浏览）

#### 步骤 3.2：到店出示并核销优惠券
* **API**: `POST /api/MemberVoucher/RedeemVoucher`（需要 Bearer Token）
* **Request Body**:
  ```json
  {
    "voucherGUID": "Voucher-xxx-xxx",
    "memberPassword": "你的会员密码",
    "outletStaffPin": "123456"
  }
  ```
* **说明**：核销成功后，该券状态将标记为 `Claimed = true`，不可重复核销。

---

### 4. 积分兑换商品礼品 (Rewards)
#### 步骤 4.1：浏览礼品清单
* **API**: `GET /api/MemberReward/GetAllRewards`（支持游客直接浏览）

#### 步骤 4.2：使用积分兑换礼品
* **API**: `POST /api/MemberReward/RedeemReward`（需要 Bearer Token）
* **Request Body**:
  ```json
  {
    "rewardGUID": "Reward-xxx-xxx",
    "memberPassword": "你的会员密码",
    "outletStaffPin": "123456"
  }
  ```
* **说明**：兑换时系统会自动核对会员积分是否足够，扣除对应积分，并写入兑换历史。

---

### 5. 个人历史流水汇总 (History)
* **API**: `GET /api/MemberHistory/GetHistoryRecord`（需要 Bearer Token）
* **功能**：一键聚合该会员的优惠券核销记录、积分变更记录和礼品兑换记录。

---

## 四、 常见问题 (FAQ)

1. **手机号格式要求？**  
   输入的手机号必须以 `0` 开头（例如 `0123456789` 或 `01123456789`），后端会自动规范化为国际格式 `+60123456789`。

2. **店员 PIN 码不对？**  
   请先确保调用过 `GET /api/ManageDefault/CreateDefaults`。预设默认店员 PIN 码为 **`123456`**。

3. **接口报 401 Unauthorized？**  
   表示该接口需要会员登录。请先调用 `MemberLogin` 取得 `successToken`，并在请求头附带 `Authorization: Bearer <token>`。
