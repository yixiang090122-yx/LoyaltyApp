﻿namespace LoyaltyAppAPI.DTO.Feedback
{
    public class GetFeedback
    {
        public int? MemberID { get; set; }
    }
}
