﻿namespace LoyaltyAppAPI.DTO
{
    public class TokenDTO
    {
        public string? Username { get; set; }
        public string? Password { get; set; }
    }
}
