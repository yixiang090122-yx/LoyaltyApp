﻿namespace LoyaltyAppAPI.DTO.Record
{
    public class RewardAssignDTO
    {
        public int RewardRecordID { get; set; }
        public long? MemberRedeemDateTime { get; set; }
        public string? OutletName { get; set; }
        public string? OutletStaffName { get; set; }
        public string? MemberName { get; set; }
        public string? MemberPhoneNumber { get; set; }
        public string? RewardTitle { get; set; }
        public string? RewardName { get; set; }
        public string? RewardDescription { get; set; }
    }
}
