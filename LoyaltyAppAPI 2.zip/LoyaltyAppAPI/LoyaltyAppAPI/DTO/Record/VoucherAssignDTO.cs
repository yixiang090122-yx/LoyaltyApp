﻿namespace LoyaltyAppAPI.DTO.Record
{
    public class VoucherAssignDTO
    {
        public int VoucherRecordID { get; set; }
        public string? VoucherName { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public string? MemberName { get; set; }
        public string? MemberPhoneNumber { get; set; }
        public string? OutletName { get; set; }
        public string? OutletStaffName { get; set; }
        public long? MemberRedeemDateTime { get; set; }
    }
}
