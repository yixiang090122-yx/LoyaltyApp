﻿namespace LoyaltyAppAPI.DTO.Outlet
{
    public class GetOutlet
    {
        public int? OutletID { get; set; }
        public string? OutletName { get; set; }
    }
}
