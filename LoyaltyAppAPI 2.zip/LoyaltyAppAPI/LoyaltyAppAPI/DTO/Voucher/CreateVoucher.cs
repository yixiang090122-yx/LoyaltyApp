﻿using LoyaltyAppAPI.Models;

namespace LoyaltyAppAPI.DTO.Voucher
{
    public class CreateVoucher
    {
        public int VoucherID { get; set; }
        public string? VoucherGUID { get; set; }
        public string? VoucherName { get; set; }
        public string? Image { get; set; }
        public string? Title { get; set; }
        public string? Subtitle { get; set; }
        public string? ShortTitle { get; set; }
        public string? Description { get; set; }
        public string? TNC { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ExpiredDate { get; set; }
        public string? VoucherStatus { get; set; }
        public string? VoucherRules { get; set; }
    }
}
