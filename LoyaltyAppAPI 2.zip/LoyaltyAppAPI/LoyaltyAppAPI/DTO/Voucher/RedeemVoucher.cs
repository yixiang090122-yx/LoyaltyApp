﻿namespace LoyaltyAppAPI.DTO.Voucher
{
    public class RedeemVoucher
    {
        public string? VoucherGUID { get; set; }
        public string? MemberPassword { get; set; }
        public string? OutletStaffPin { get; set; }
    }
}
