﻿using LoyaltyAppAPI.Models;

namespace LoyaltyAppAPI.DTO.Voucher
{
    public class EditVoucher
    {
        public int VoucherID { get; set; }
        public string? VoucherName { get; set; }
        public string? Title { get; set; }
        public string? Subtitle { get; set; }
        public string? ShortTitle { get; set; }
        public string? Description { get; set; }
        public string? TNC { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ExpiredDate { get; set; }
        public string? VoucherStatus { get; set; }
        public IFormFile? file { get; set; }  // Use this for the uploaded file
        public string VoucherRules { get; set; }
    }
}
