﻿namespace LoyaltyAppAPI.DTO.Voucher
{
    public class FilterVouchers
    {
        public List<LoyaltyAppAPI.Models.Voucher>? ActiveVouchers { get; set; }
        public List<LoyaltyAppAPI.Models.Voucher>? ClaimedVouchers { get; set; }
        public List<LoyaltyAppAPI.Models.Voucher>? ExpiredVouchers { get; set; }
    }
}
