﻿namespace LoyaltyAppAPI.DTO.History
{
    using System;
    using LoyaltyAppAPI.Models;

    public enum HistoryType
    {
        Voucher,
        Reward,
        Point
    }

    public enum DateRange
    {
        All,
        Today,
        ThisWeek,
        ThisMonth,
        ThisYear
    }

    public enum PointRecordStatus
    {
        Pending, Approve, Rejected
    }

    public class HistoryRecord
    {
        public int RecordID { get; set; }
        public string? RecordGUID { get; set; }
        public int? MemberID { get; set; }
        public int? OutletStaffID { get; set; }
        public bool? Claim { get; set; }
        public DateTime? Date { get; set; }
        public string? Description { get; set; }
        public HistoryType RecordType { get; set; }
        public int? Points { get; set; }
        public string? Remark { get; set; }
        public string? Image { get; set; }
        public string? Status { get; set; }
        public Voucher? VoucherDetail { get; set; }
        public Rewards? RewardDetail { get; set; }
        public PointRecord? PointDetail { get; set; }
    }

    public class HistoryService
    {
        private readonly List<VoucherRecord> _voucherRecords;
        private readonly List<RewardRecord> _rewardRecords;
        private readonly List<PointRecord> _pointRecords;
        private readonly List<Voucher> _vouchers;
        private readonly List<Rewards> _rewards;

        public HistoryService(List<VoucherRecord> voucherRecords, List<RewardRecord> rewardRecords, List<PointRecord> pointRecords, List<Voucher> vouchers, List<Rewards> rewards)
        {
            _voucherRecords = voucherRecords;
            _rewardRecords = rewardRecords;
            _pointRecords = pointRecords;
            _vouchers = vouchers;
            _rewards = rewards;
        }

        public List<HistoryRecord> GetHistoryRecords(DateRange? dateRange = null, List<HistoryType>? types = null)
        {
            var historyRecords = new List<HistoryRecord>();

            historyRecords.AddRange(_voucherRecords.Select(v => new HistoryRecord
            {
                RecordID = v.VoucherRecordID,
                RecordGUID = v.VoucherRecordGUID,
                MemberID = v.MemberID,
                OutletStaffID = v.OutletStaffID,
                Claim = v.Claim,
                Date = ConvertUnixTimeToDateTime(v.MemberRedeemDateTime),
                RecordType = HistoryType.Voucher,
                Status = v.Claim == true ? "Success" : "Failed",
                VoucherDetail = v.VoucherID != null ? _vouchers.FirstOrDefault(vd => vd.VoucherID == v.VoucherID) : null
            }));

            historyRecords.AddRange(_rewardRecords.Select(r => new HistoryRecord
            {
                RecordID = r.RewardRecordID,
                RecordGUID = r.RewardRecordGUID,
                MemberID = r.MemberID,
                OutletStaffID = r.OutletStaffID,
                Points = r.Rewards?.Point,
                Claim = r.Claim,
                Date = ConvertUnixTimeToDateTime(r.MemberRedeemDateTime),
                RecordType = HistoryType.Reward,
                Status = r.Claim == true ? "Success" : "Failed",
                RewardDetail = r.RewardsID != null ? _rewards.FirstOrDefault(rd => rd.RewardsID == r.RewardsID) : null
            }));

            historyRecords.AddRange(_pointRecords.Select(p => new HistoryRecord
            {
                RecordID = p.PointRecordID,
                RecordGUID = p.PointRecordGUID,
                MemberID = p.MemberID,
                OutletStaffID = p.OutletStaffID,
                Date = p.DateAssign,
                Description = p.Description,
                Points = p.Point,
                Remark = p.Remark,
                Image = p.Image,
                RecordType = HistoryType.Point,
                Status = p.PointRecordStatus.ToString(),
                PointDetail = _pointRecords.FirstOrDefault(x => x.PointRecordGUID == p.PointRecordGUID)
            }));

            if (dateRange.HasValue)
            {
                var (startDate, endDate) = GetDateRange(dateRange.Value);
                historyRecords = historyRecords.Where(hr => hr.Date >= startDate && hr.Date <= endDate).ToList();
            }

            if (types != null && types.Any())
            {
                historyRecords = historyRecords.Where(hr => types.Contains(hr.RecordType)).ToList();
            }

            return historyRecords;
        }

        private DateTime? ConvertUnixTimeToDateTime(long? unixTimeMillis)
        {
            if (unixTimeMillis == null) return null;
            DateTimeOffset dateTimeOffset = DateTimeOffset.FromUnixTimeMilliseconds(unixTimeMillis.Value);
            return dateTimeOffset.LocalDateTime;
        }

        private (DateTime start, DateTime end) GetDateRange(DateRange range)
        {
            DateTime now = DateTime.Now;
            return range switch
            {
                DateRange.All => (DateTime.MinValue, DateTime.MaxValue),
                DateRange.Today => (now.Date, now.Date.AddDays(1).AddTicks(-1)),
                DateRange.ThisWeek => (now.Date.AddDays(-(int)now.DayOfWeek), now.Date.AddDays(7 - (int)now.DayOfWeek).AddTicks(-1)),
                DateRange.ThisMonth => (new DateTime(now.Year, now.Month, 1), new DateTime(now.Year, now.Month, 1).AddMonths(1).AddTicks(-1)),
                DateRange.ThisYear => (new DateTime(now.Year, 1, 1), new DateTime(now.Year, 1, 1).AddYears(1).AddTicks(-1)),
                _ => throw new ArgumentOutOfRangeException(nameof(range), range, null)
            };
        }
    }

}
