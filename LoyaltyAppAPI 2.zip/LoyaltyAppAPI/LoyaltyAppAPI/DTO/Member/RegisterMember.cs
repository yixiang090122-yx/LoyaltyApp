﻿namespace LoyaltyAppAPI.DTO.Member
{
    public class RegisterMember
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
        public IFormFile? Image { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Birthday { get; set; }
        public string? ReferralBy { get; set; }
        public string? Password { get; set; }
    }
}
