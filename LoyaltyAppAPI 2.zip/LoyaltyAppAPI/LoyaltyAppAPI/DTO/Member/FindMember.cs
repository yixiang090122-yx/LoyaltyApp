namespace LoyaltyAppAPI.DTO.Member
{
    public class FindMember
    {
        public int? MemberID { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Password { get; set; }
    }
}
