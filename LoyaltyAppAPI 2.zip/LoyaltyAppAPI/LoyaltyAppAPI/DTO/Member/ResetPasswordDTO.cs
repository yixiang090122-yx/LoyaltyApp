namespace LoyaltyAppAPI.DTO.Member
{
    public class ResetPasswordDTO
    {
        public string? PhoneNumber { get; set; }
        public string? Email { get; set; }
        public string OTP { get; set; } = string.Empty;
        public string NewPassword { get; set; } = string.Empty;
    }
}
