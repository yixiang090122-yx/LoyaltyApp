namespace LoyaltyAppAPI.DTO.Member
{
    public class RequestOtpDTO
    {
        public string? PhoneNumber { get; set; }
        public string? Email { get; set; }
    }
}
