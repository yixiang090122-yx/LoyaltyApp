﻿namespace LoyaltyAppAPI.DTO.Member
{
    public class UpdateMember
    {
      
        public string? Name { get; set; }
        public string? Email { get; set; }
        public IFormFile? Image { get; set; }

    }
}
