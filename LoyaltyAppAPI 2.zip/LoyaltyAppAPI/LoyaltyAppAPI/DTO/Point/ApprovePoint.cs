﻿namespace LoyaltyAppAPI.DTO.Point
{
    public class ApprovePoint
    {
        public int Point { get; set; }
        public string? OutletGUID { get; set; }
        public string? Pin { get; set; }
        public PointRecordStatus? PointRecordStatus { get; set; }
        public string? Code { get; set; }
        public string? Remark { get; set; }
        public IFormFile? Image { get; set; }
    }
}
