﻿namespace LoyaltyAppAPI.DTO.Point
{
    public class OutletAssignRecord
    {
        public int Point { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Pin { get; set; }
        public int? OutletID { get; set; }
    }
}
