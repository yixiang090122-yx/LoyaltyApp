﻿namespace LoyaltyAppAPI.DTO.Point
{
    public class RejectPointDTO
    {
        public string Id { get; set; }
        public OutletAssignRecord? AssignPoint { get; set; }
    }
}
