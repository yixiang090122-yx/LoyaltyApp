﻿namespace LoyaltyAppAPI.DTO.Reward
{
    public class RedeemReward
    {
        public string? RewardGUID { get; set; }
        public string? MemberPassword { get; set; }
        public string? OutletStaffPin { get; set; }
    }
}
