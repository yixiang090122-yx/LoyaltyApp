﻿namespace LoyaltyAppAPI.DTO.Reward
{
    public class EditReward
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Title { get; set; }
        public string? SubTitle { get; set; }
        public int? Point { get; set; }
        public string? ShortTitle { get; set; }
        public string? Description { get; set; }
        public string? TnC { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ExpireDate { get; set; }
        public string? Status { get; set; }
        public string? Category { get; set; }
        public IFormFile? file { get; set; }  // Use this for the uploaded file
    }
}
