﻿namespace LoyaltyAppAPI.DTO.Reward
{
    public class CreateReward
    {
        public string? FullName { get; set; }
        public string? Image { get; set; }
        public string? Title { get; set; }
        public string? SubTitle { get; set; }
        public int? Point { get; set; }
        public string? ShortTitle { get; set; }
        public string? Description { get; set; }
        public string? TnC { get; set; }
        public string? Status { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ExpireDate { get; set; }
    }
}
